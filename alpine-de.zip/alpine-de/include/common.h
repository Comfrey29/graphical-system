#ifndef COMMON_H
#define COMMON_H

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <X11/XKBlib.h>
#include <X11/extensions/Xrender.h>
#include <X11/extensions/Xcomposite.h>
#include <X11/extensions/shape.h>
#include <X11/Xft/Xft.h>
#include <fontconfig/fontconfig.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <math.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <pthread.h>

/* ── macOS Color Palette ─────────────────────────────────────────── */
#define COLOR_BG_DARK       0x1E1E2E   /* dark background */
#define COLOR_BG_PANEL      0x181825   /* panel background */
#define COLOR_BG_CARD       0x313244   /* card/window bg */
#define COLOR_ACCENT_BLUE   0x89B4FA   /* blue accent */
#define COLOR_ACCENT_RED    0xFF5F57   /* close button */
#define COLOR_ACCENT_YELLOW 0xFFBD2E   /* minimize button */
#define COLOR_ACCENT_GREEN  0x28CA41   /* maximize button */
#define COLOR_TEXT_PRIMARY  0xCDD6F4   /* primary text */
#define COLOR_TEXT_SECONDARY 0xA6ADC8  /* secondary text */
#define COLOR_BORDER        0x45475A   /* border color */
#define COLOR_SELECTION     0x45475A   /* selection */
#define COLOR_HOVER         0x585B70   /* hover state */
#define COLOR_TITLEBAR      0x24273A   /* titlebar */
#define COLOR_DOCK_BG       0x1E1E2E   /* dock background */
#define COLOR_TOPBAR_BG     0x1E1E2E   /* topbar background */
#define COLOR_WHITE         0xFFFFFF
#define COLOR_BLACK         0x000000

/* ── Layout Constants ────────────────────────────────────────────── */
#define TOPBAR_HEIGHT       28
#define DOCK_HEIGHT         64
#define DOCK_ICON_SIZE      48
#define DOCK_ICON_MAX       80
#define DOCK_PADDING        8
#define DOCK_MAX_WIDTH      600
#define TITLEBAR_HEIGHT     28
#define BORDER_WIDTH        1
#define CORNER_RADIUS       8
#define BUTTON_SIZE         12
#define BUTTON_MARGIN       8

/* ── Font Definitions ────────────────────────────────────────────── */
#define FONT_UI             "SF Pro Display:size=11"
#define FONT_UI_BOLD        "SF Pro Display:size=11:bold"
#define FONT_UI_SMALL       "SF Pro Display:size=9"
#define FONT_UI_LARGE       "SF Pro Display:size=14:bold"
#define FONT_FALLBACK       "DejaVu Sans:size=11"
#define FONT_MONO           "JetBrainsMono Nerd Font:size=10"

/* ── Atoms ───────────────────────────────────────────────────────── */
typedef struct {
    Atom WM_PROTOCOLS;
    Atom WM_DELETE_WINDOW;
    Atom WM_STATE;
    Atom WM_NAME;
    Atom NET_WM_NAME;
    Atom NET_WM_STATE;
    Atom NET_WM_STATE_FULLSCREEN;
    Atom NET_WM_STATE_MAXIMIZED_VERT;
    Atom NET_WM_STATE_MAXIMIZED_HORZ;
    Atom NET_WM_WINDOW_TYPE;
    Atom NET_WM_WINDOW_TYPE_DIALOG;
    Atom NET_WM_WINDOW_TYPE_NORMAL;
    Atom NET_WM_WINDOW_TYPE_DOCK;
    Atom NET_WM_STRUT;
    Atom NET_WM_STRUT_PARTIAL;
    Atom NET_ACTIVE_WINDOW;
    Atom NET_CLIENT_LIST;
    Atom NET_WORKAREA;
    Atom NET_SUPPORTING_WM_CHECK;
    Atom MOTIF_WM_HINTS;
} Atoms;

/* ── Utility Macros ──────────────────────────────────────────────── */
#define MAX(a, b)     ((a) > (b) ? (a) : (b))
#define MIN(a, b)     ((a) < (b) ? (a) : (b))
#define CLAMP(v,lo,hi) MIN(MAX(v,lo),hi)
#define ARRLEN(a)     (sizeof(a)/sizeof(a[0]))

/* ── Color helpers ───────────────────────────────────────────────── */
static inline unsigned long rgb(int r, int g, int b) {
    return ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
}

static inline unsigned long hex_color(Display *dpy, unsigned long hex) {
    int r = (hex >> 16) & 0xFF;
    int g = (hex >> 8)  & 0xFF;
    int b =  hex        & 0xFF;
    XColor c;
    char name[16];
    snprintf(name, sizeof(name), "#%02X%02X%02X", r, g, b);
    if (XParseColor(dpy, DefaultColormap(dpy, DefaultScreen(dpy)), name, &c) &&
        XAllocColor(dpy, DefaultColormap(dpy, DefaultScreen(dpy)), &c))
        return c.pixel;
    return WhitePixel(dpy, DefaultScreen(dpy));
}

/* ── IPC via X properties ────────────────────────────────────────── */
#define IPC_PROP_FOCUS  "_DE_FOCUS_TITLE"
#define IPC_PROP_NOTIFY "_DE_NOTIFICATION"

static inline void ipc_set_prop(Display *dpy, const char *prop, const char *val) {
    Atom a = XInternAtom(dpy, prop, False);
    XChangeProperty(dpy, DefaultRootWindow(dpy), a, XA_STRING, 8,
                    PropModeReplace, (unsigned char*)val, strlen(val));
    XFlush(dpy);
}

static inline char *ipc_get_prop(Display *dpy, const char *prop) {
    Atom a = XInternAtom(dpy, prop, False);
    Atom type; int fmt; unsigned long n, after;
    unsigned char *data = NULL;
    if (XGetWindowProperty(dpy, DefaultRootWindow(dpy), a, 0, 256,
                           False, XA_STRING, &type, &fmt, &n, &after, &data)
        == Success && data)
        return (char*)data;
    return NULL;
}

/* ── Spawn helper ────────────────────────────────────────────────── */
static inline void spawn(const char *cmd) {
    if (fork() == 0) {
        setsid();
        execl("/bin/sh", "sh", "-c", cmd, NULL);
        _exit(1);
    }
}

/* ── Draw rounded rectangle ──────────────────────────────────────── */
static inline void draw_rounded_rect(Display *dpy, Window w, GC gc,
                                     int x, int y, int width, int height, int r) {
    /* Simulate rounded corners with arcs and lines */
    XFillRectangle(dpy, w, gc, x+r, y, width-2*r, height);
    XFillRectangle(dpy, w, gc, x, y+r, width, height-2*r);
    XFillArc(dpy, w, gc, x,           y,           2*r, 2*r, 90*64,  90*64);
    XFillArc(dpy, w, gc, x+width-2*r, y,           2*r, 2*r,  0,     90*64);
    XFillArc(dpy, w, gc, x,           y+height-2*r,2*r, 2*r,180*64,  90*64);
    XFillArc(dpy, w, gc, x+width-2*r, y+height-2*r,2*r, 2*r,270*64,  90*64);
}

/* ── XftDraw text helper ─────────────────────────────────────────── */
static inline void xft_draw_string(Display *dpy, Window win, XftDraw *draw,
                                   XftFont *font, XftColor *color,
                                   int x, int y, const char *text) {
    if (!text || !draw || !font || !color) return;
    XftDrawStringUtf8(draw, color, font, x, y, (const FcChar8*)text, strlen(text));
}

/* ── Get XftFont with fallback ───────────────────────────────────── */
static inline XftFont *load_font(Display *dpy, int screen, const char *name) {
    XftFont *f = XftFontOpenName(dpy, screen, name);
    if (!f) f = XftFontOpenName(dpy, screen, FONT_FALLBACK);
    return f;
}

/* ── XftColor from hex ───────────────────────────────────────────── */
static inline int alloc_xft_color(Display *dpy, int screen,
                                   unsigned long hex, XftColor *out) {
    XRenderColor rc;
    rc.red   = ((hex >> 16) & 0xFF) * 257;
    rc.green = ((hex >>  8) & 0xFF) * 257;
    rc.blue  = ( hex        & 0xFF) * 257;
    rc.alpha = 0xFFFF;
    return XftColorAllocValue(dpy, DefaultVisual(dpy, screen),
                              DefaultColormap(dpy, screen), &rc, out);
}

#endif /* COMMON_H */
