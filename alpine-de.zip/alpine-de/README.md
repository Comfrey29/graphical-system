# Alpine Desktop Environment

Un entorn d'escriptori minimalista d'estil macOS, programat completament en C pur per a Alpine Linux aarch64.

---

## Arquitectura del sistema

```
┌──────────────────────────────────────────────────────────┐
│                     TOP BAR (topbar)                      │
│  [🍎 Menú] [Fitxer] [Edita] [Visualitza]  [App]  [🔊⚡🕐] │
├──────────────────────────────────────────────────────────┤
│                                                          │
│   ┌─────────────────────────────┐                        │
│   │ ● ● ●  Finestra             │                        │
│   │─────────────────────────────│  ← wm (Window Manager) │
│   │  Contingut de l'aplicació   │                        │
│   └─────────────────────────────┘                        │
│                                                          │
│         ┌──────────────────┐                             │
│         │ 🔍 Cerca...      │  ← launcher (Alt+Space)     │
│         └──────────────────┘                             │
│                                                          │
│                    ┌──────────────────┐  ← notify        │
│                    │ 🔔 Títol         │                  │
│                    │ Cos del missatge │                  │
│                    └──────────────────┘                  │
├──────────────────────────────────────────────────────────┤
│    [🗂️] [💻] [🦊] [📝] [🗑️]    ← DOCK (dock)            │
└──────────────────────────────────────────────────────────┘
```

## Mòduls

| Binari       | Font                   | Funció                              |
|-------------|------------------------|-------------------------------------|
| `wm`         | `src/wm.c`             | Gestor de finestres ICCCM/EWMH      |
| `topbar`     | `src/topbar.c`         | Barra superior amb menús i rellotge |
| `dock`       | `src/dock.c`           | Dock inferior amb efecte zoom       |
| `launcher`   | `src/launcher.c`       | Cercador tipus Spotlight            |
| `notify`     | `src/notifications.c`  | Dimoni de notificacions             |
| `wallpaper`  | `src/wallpaper.c`      | Establidor de fons d'escriptori     |
| `screenshot` | `src/screenshot.c`     | Captura de pantalla                 |

## Dependències

### Compilació
- `gcc` ≥ 10
- `make`
- `pkgconf` / `pkg-config`
- `musl-dev` (Alpine)

### Biblioteques X11
- `libx11-dev` — Xlib core
- `libxext-dev` — X Extensions
- `libxrender-dev` — XRender (antialiasing)
- `libxft-dev` — Xft (text amb antialiasing)
- `fontconfig-dev` — gestió de fonts
- `freetype-dev` — rasterització de fonts

### Altres
- `alsa-lib-dev` — volum (topbar)
- `libpng-dev` — PNG (wallpaper, screenshot)

### Opcionals
- `picom` / `compton` — compositor per a ombres i transparència
- `xterm` — terminal (dock)
- `thunar` — gestor de fitxers (dock)
- `firefox` — navegador (dock)

## Instal·lació

### 1. Instal·lar dependències (com a root)

```sh
sh scripts/install-deps.sh
```

O manualment:
```sh
apk add gcc make pkgconf musl-dev \
        libx11-dev libxext-dev libxrender-dev libxft-dev \
        fontconfig-dev freetype-dev \
        alsa-lib-dev libpng-dev \
        font-dejavu xterm
```

### 2. Compilar

```sh
make
```

O amb un prefix personalitzat:
```sh
make PREFIX=/usr install
```

### 3. Instal·lar

```sh
make install   # instal·la a /usr/local/bin per defecte
```

### 4. Iniciar

**Des d'un TTY:**
```sh
startx
```

**Des d'un display manager (GDM, SDDM, LightDM):**  
Afegiu una entrada de sessió a `/usr/share/xsessions/alpine-de.desktop`:
```ini
[Desktop Entry]
Name=Alpine DE
Exec=/usr/local/bin/start-de
Type=Application
```

## Ús

### Dreceres de teclat

| Drecera          | Acció                                 |
|------------------|---------------------------------------|
| `Alt+Tab`        | Canviar entre finestres               |
| `Alt+F4`         | Tancar finestra activa                |
| `Alt+Return`     | Maximitzar / restaurar finestra       |
| `Alt+Space`      | Obrir el Launcher (Spotlight)         |
| `Alt+Clic`       | Moure finestra des de qualsevol punt  |
| `Shift+Alt+F3`   | Captura de pantalla (pantalla completa)|

### Launcher (Alt+Space)

- Escriviu per cercar aplicacions i comandes
- `↑` / `↓` per navegar pels resultats
- `Enter` per executar
- `Esc` per tancar

### Dock

- **Clic simple** → Llança l'aplicació
- **Clic dret** → Menú contextual (Opcions / Sortir)
- **Arrossegar** → Reordenar icones

### Barra superior

- Clic a **🍎** → Menú del sistema (Sobre, Configuració, Bloquejar, Tancar sessió, Apagar)
- Clic a **Fitxer / Edita / Visualitza** → Menú global de l'aplicació activa
- Clic al **rellotge** → Mostra la data actual

### Gestió de finestres

- **Arrossegar barra de títol** → Moure finestra
- **Cantonada inferior dreta** → Redimensionar
- **Botó vermell (●)** → Tancar
- **Botó groc (●)** → Minimitzar
- **Botó verd (●)** → Maximitzar / restaurar
- **Arrossegar a la vora esquerra** → Ajusta a mig esquerre
- **Arrossegar a la vora dreta** → Ajusta a mig dret
- **Arrossegar a la part superior** → Maximitza

## Personalització

Editeu `~/.config/alpine-de/de.conf`:

```ini
# Canviar colors
color_accent = #CBA6F7   # Mauve (Catppuccin)

# Canviar icones de dock editant src/dock.c, array 'icons[]'

# Canviar fons d'escriptori
wallpaper_path = ~/Imatges/fons.png
wallpaper_mode = scaled
```

### Canviar la font
Si no teniu SF Pro, instal·leu Inter (gratuïta, similiar a SF Pro):
```sh
apk add font-inter
```
O editeu `include/common.h` i canvieu `FONT_UI`:
```c
#define FONT_UI  "Inter:size=11"
```

### Paleta de colors alternativa
Editeu les constants `COLOR_*` a `include/common.h`:

**Gruvbox Dark:**
```c
#define COLOR_BG_DARK    0x282828
#define COLOR_ACCENT_BLUE 0x458588
#define COLOR_TEXT_PRIMARY 0xEBDBB2
```

**Nord:**
```c
#define COLOR_BG_DARK    0x2E3440
#define COLOR_ACCENT_BLUE 0x88C0D0
#define COLOR_TEXT_PRIMARY 0xECEFF4
```

## Estructura del projecte

```
alpine-de/
├── Makefile
├── README.md
├── include/
│   └── common.h          ← constants, colors, helpers compartits
├── src/
│   ├── wm.c              ← window manager
│   ├── topbar.c          ← barra superior
│   ├── dock.c            ← dock inferior
│   ├── launcher.c        ← spotlight launcher
│   ├── notifications.c   ← dimoni de notificacions
│   ├── wallpaper.c       ← setter de fons
│   └── screenshot.c      ← captura de pantalla
├── config/
│   ├── de.conf           ← configuració principal
│   └── picom.conf        ← configuració del compositor
└── scripts/
    ├── xinitrc           ← sessió X11
    ├── start-de          ← launcher des de DM
    └── install-deps.sh   ← instal·lador de dependències
```

## Comunicació entre processos (IPC)

Els components es comuniquen via propietats X11 a la finestra arrel:

| Propietat       | Tipus    | Escriu  | Llegeix         | Contingut              |
|-----------------|----------|---------|-----------------|------------------------|
| `_DE_FOCUS_TITLE` | `STRING` | `wm`    | `topbar`        | Títol de la finestra activa |
| `_DE_NOTIFICATION` | `STRING` | qualsevol | `notify`    | `Títol\nCos`           |
| `_NET_ACTIVE_WINDOW` | `WINDOW` | `wm` | tots          | Finestra EWMH activa   |
| `_NET_CLIENT_LIST` | `WINDOW[]` | `wm` | tots         | Llista de clients      |

## Notes aarch64

- Compilat amb `-O2` per als cores Cortex-A del Raspberry Pi 4/5 i altres SBC
- **No** utilitza instruccions x86 específiques — pur C POSIX
- El backend `glx` del picom requereix GPU amb driver Mesa (e.g. `mesa-dri-gallium` per a `vc4` / `v3d`)
- Si no hi ha GPU, useu `backend = "xrender"` a `picom.conf`
- Per a Raspberry Pi, afegiu `dtoverlay=vc4-kms-v3d` a `/boot/config.txt`

## Llicència

MIT — lliure per a ús personal i comercial.
