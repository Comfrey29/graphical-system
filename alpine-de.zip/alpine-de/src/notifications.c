/*
 * notifications.c — Alpine Desktop Environment: Notification Daemon
 * macOS-style slide-in notifications, auto-dismiss after 4s
 * Compile: gcc -O2 -o notify notifications.c -lX11 -lXft -lfontconfig -lm
 * Usage: notify 'Title' 'Body message'   (single-shot)
 *        notify --daemon                  (listen on IPC)
 */
#include "../include/common.h"
#include <sys/time.h>

/* ── Constants ───────────────────────────────────────────────────── */
#define NOTIF_W         320
#define NOTIF_H         72
#define NOTIF_MARGIN    12
#define NOTIF_DURATION  4000   /* ms before auto-dismiss */
#define NOTIF_SLIDE_MS  200    /* slide animation duration */
#define MAX_NOTIFS      6
#define ICON_R          18     /* icon circle radius */

/* ── Notification ─────────────────────────────────────────────────── */
typedef struct {
    char  title[128];
    char  body[256];
    Window win;
    int   x, y;
    int   target_y;
    long  created_ms;  /* epoch ms when created */
    int   alive;
    double alpha;      /* 0.0 – 1.0 */
} Notif;

/* ── Daemon state ────────────────────────────────────────────────── */
typedef struct {
    Display  *dpy;
    int       screen;
    Window    root;
    int       sw, sh;
    GC        gc;
    XftFont  *font_title;
    XftFont  *font_body;
    XftColor  col_title, col_body;
    unsigned long col_bg, col_border, col_icon;
    Notif     notifs[MAX_NOTIFS];
    int       nnotifs;
} ND;

static ND nd;

/* ── Time helper ──────────────────────────────────────────────────── */
static long now_ms(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000L + tv.tv_usec / 1000;
}

/* ── Create notification window ───────────────────────────────────── */
static void nd_create_win(Notif *n) {
    int x = nd.sw - NOTIF_W - NOTIF_MARGIN;
    /* stack from top-right, below topbar */
    int base_y = TOPBAR_HEIGHT + NOTIF_MARGIN;
    for (int i = 0; i < nd.nnotifs - 1; i++) {
        if (nd.notifs[i].alive) base_y += NOTIF_H + NOTIF_MARGIN;
    }
    n->x        = x;
    n->y        = -NOTIF_H;          /* start above screen */
    n->target_y = base_y;

    XSetWindowAttributes wa;
    wa.background_pixel  = nd.col_bg;
    wa.border_pixel      = nd.col_border;
    wa.override_redirect = True;
    wa.event_mask        = ExposureMask | ButtonPressMask;

    n->win = XCreateWindow(nd.dpy, nd.root,
                           x, n->y, NOTIF_W, NOTIF_H, 1,
                           DefaultDepth(nd.dpy, nd.screen),
                           InputOutput,
                           DefaultVisual(nd.dpy, nd.screen),
                           CWBackPixel|CWBorderPixel|CWOverrideRedirect|CWEventMask, &wa);

    /* keep above everything */
    Atom above = XInternAtom(nd.dpy, "_NET_WM_STATE_ABOVE", False);
    Atom state = XInternAtom(nd.dpy, "_NET_WM_STATE", False);
    XChangeProperty(nd.dpy, n->win, state, XA_ATOM, 32,
                    PropModeReplace, (unsigned char*)&above, 1);

    XMapRaised(nd.dpy, n->win);
}

/* ── Draw one notification ────────────────────────────────────────── */
static void nd_draw(Notif *n) {
    if (!n->win || !n->alive) return;

    /* background */
    XSetForeground(nd.dpy, nd.gc, nd.col_bg);
    draw_rounded_rect(nd.dpy, n->win, nd.gc, 0, 0, NOTIF_W, NOTIF_H, 10);

    /* border */
    XSetForeground(nd.dpy, nd.gc, nd.col_border);
    XDrawRectangle(nd.dpy, n->win, nd.gc, 0, 0, NOTIF_W-1, NOTIF_H-1);

    /* icon circle */
    XSetForeground(nd.dpy, nd.gc, nd.col_icon);
    XFillArc(nd.dpy, n->win, nd.gc,
             12, (NOTIF_H - ICON_R*2)/2, ICON_R*2, ICON_R*2, 0, 360*64);

    /* bell icon letter */
    XftDraw *draw = XftDrawCreate(nd.dpy, n->win,
                                  DefaultVisual(nd.dpy, nd.screen),
                                  DefaultColormap(nd.dpy, nd.screen));
    XftColor white;
    alloc_xft_color(nd.dpy, nd.screen, COLOR_WHITE, &white);
    int iy = (NOTIF_H + nd.font_title->ascent) / 2 - 1;
    XftDrawStringUtf8(draw, &white, nd.font_body, 14+ICON_R/2, iy,
                      (FcChar8*)"🔔", strlen("🔔"));
    XftColorFree(nd.dpy, DefaultVisual(nd.dpy, nd.screen),
                 DefaultColormap(nd.dpy, nd.screen), &white);

    /* title */
    int tx = 12 + ICON_R*2 + 10;
    int ty = NOTIF_H/2 - 2;
    XftDrawStringUtf8(draw, &nd.col_title, nd.font_title, tx, ty,
                      (FcChar8*)n->title, strlen(n->title));

    /* body */
    int by = NOTIF_H/2 + nd.font_body->ascent + 2;
    /* truncate body to fit */
    char trunc[256];
    strncpy(trunc, n->body, sizeof(trunc)-1);
    trunc[sizeof(trunc)-1] = '\0';
    int max_w = NOTIF_W - tx - 12;
    XGlyphInfo ext;
    while (strlen(trunc) > 3) {
        XftTextExtentsUtf8(nd.dpy, nd.font_body, (FcChar8*)trunc, strlen(trunc), &ext);
        if (ext.xOff <= max_w) break;
        int l = strlen(trunc) - 1;
        /* back up one char */
        while (l > 0 && (trunc[l] & 0xC0) == 0x80) l--;
        trunc[l] = '\0';
        if (strlen(trunc) > 3) { trunc[strlen(trunc)-1] = '.'; trunc[strlen(trunc)] = '.'; }
    }
    XftDrawStringUtf8(draw, &nd.col_body, nd.font_body, tx, by,
                      (FcChar8*)trunc, strlen(trunc));

    /* progress bar (time remaining) */
    long age = now_ms() - n->created_ms;
    double progress = 1.0 - CLAMP((double)age / NOTIF_DURATION, 0.0, 1.0);
    int bar_w = (int)((NOTIF_W - 24) * progress);
    XSetForeground(nd.dpy, nd.gc, hex_color(nd.dpy, COLOR_BORDER));
    XFillRectangle(nd.dpy, n->win, nd.gc, 12, NOTIF_H-4, NOTIF_W-24, 2);
    XSetForeground(nd.dpy, nd.gc, hex_color(nd.dpy, COLOR_ACCENT_BLUE));
    if (bar_w > 0) XFillRectangle(nd.dpy, n->win, nd.gc, 12, NOTIF_H-4, bar_w, 2);

    XftDrawDestroy(draw);
    XFlush(nd.dpy);
}

/* ── Push new notification ────────────────────────────────────────── */
static void nd_push(const char *title, const char *body) {
    /* find free slot */
    Notif *n = NULL;
    if (nd.nnotifs < MAX_NOTIFS) {
        n = &nd.notifs[nd.nnotifs++];
    } else {
        /* evict oldest */
        n = &nd.notifs[0];
        if (n->win) { XDestroyWindow(nd.dpy, n->win); n->win = 0; }
        memmove(&nd.notifs[0], &nd.notifs[1], (MAX_NOTIFS-1)*sizeof(Notif));
        nd.nnotifs--;
        n = &nd.notifs[nd.nnotifs++];
    }
    memset(n, 0, sizeof(*n));
    strncpy(n->title, title, sizeof(n->title)-1);
    strncpy(n->body,  body,  sizeof(n->body)-1);
    n->alive      = 1;
    n->created_ms = now_ms();
    n->alpha      = 1.0;
    nd_create_win(n);
    nd_draw(n);
}

/* ── Dismiss notification ─────────────────────────────────────────── */
static void nd_dismiss(Notif *n) {
    if (!n->alive) return;
    n->alive = 0;
    if (n->win) { XDestroyWindow(nd.dpy, n->win); n->win = 0; }
}

/* ── Restack notifications after dismiss ──────────────────────────── */
static void nd_restack(void) {
    int y = TOPBAR_HEIGHT + NOTIF_MARGIN;
    for (int i = 0; i < nd.nnotifs; i++) {
        if (!nd.notifs[i].alive) continue;
        nd.notifs[i].target_y = y;
        y += NOTIF_H + NOTIF_MARGIN;
    }
}

/* ── Init ─────────────────────────────────────────────────────────── */
static void nd_init(void) {
    nd.dpy    = XOpenDisplay(NULL);
    if (!nd.dpy) { fprintf(stderr, "notify: cannot open display\n"); exit(1); }
    nd.screen = DefaultScreen(nd.dpy);
    nd.root   = RootWindow(nd.dpy, nd.screen);
    nd.sw     = DisplayWidth(nd.dpy, nd.screen);
    nd.sh     = DisplayHeight(nd.dpy, nd.screen);
    nd.nnotifs = 0;

    nd.col_bg     = hex_color(nd.dpy, 0x24273A);
    nd.col_border = hex_color(nd.dpy, COLOR_BORDER);
    nd.col_icon   = hex_color(nd.dpy, COLOR_ACCENT_BLUE);

    alloc_xft_color(nd.dpy, nd.screen, COLOR_TEXT_PRIMARY,   &nd.col_title);
    alloc_xft_color(nd.dpy, nd.screen, COLOR_TEXT_SECONDARY, &nd.col_body);

    nd.font_title = load_font(nd.dpy, nd.screen, FONT_UI_BOLD);
    nd.font_body  = load_font(nd.dpy, nd.screen, FONT_UI_SMALL);
    nd.gc = XCreateGC(nd.dpy, nd.root, 0, NULL);
}

/* ── Main loop ────────────────────────────────────────────────────── */
static void nd_run(void) {
    XEvent ev;
    struct timespec ts = { 0, 30 * 1000000L };

    while (1) {
        while (XPending(nd.dpy)) {
            XNextEvent(nd.dpy, &ev);
            switch (ev.type) {
                case Expose:
                    for (int i = 0; i < nd.nnotifs; i++)
                        if (nd.notifs[i].win == ev.xexpose.window)
                            nd_draw(&nd.notifs[i]);
                    break;
                case ButtonPress:
                    /* click dismisses */
                    for (int i = 0; i < nd.nnotifs; i++) {
                        if (nd.notifs[i].win == ev.xbutton.window) {
                            nd_dismiss(&nd.notifs[i]);
                            nd_restack();
                        }
                    }
                    break;
                default: break;
            }
        }

        long now = now_ms();
        int changed = 0;

        for (int i = 0; i < nd.nnotifs; i++) {
            Notif *n = &nd.notifs[i];
            if (!n->alive) continue;

            /* slide animation */
            if (n->y != n->target_y) {
                int step = MAX(1, abs(n->target_y - n->y) / 4);
                if (n->y < n->target_y) n->y = MIN(n->y + step, n->target_y);
                else                    n->y = MAX(n->y - step, n->target_y);
                XMoveWindow(nd.dpy, n->win, n->x, n->y);
                changed = 1;
            }

            /* auto-dismiss */
            if (now - n->created_ms > NOTIF_DURATION) {
                nd_dismiss(n);
                nd_restack();
                changed = 1;
                continue;
            }

            nd_draw(n);
        }

        /* compact: remove dead entries */
        int j = 0;
        for (int i = 0; i < nd.nnotifs; i++)
            if (nd.notifs[i].alive) nd.notifs[j++] = nd.notifs[i];
        nd.nnotifs = j;

        (void)changed;
        nanosleep(&ts, NULL);
    }
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(int argc, char *argv[]) {
    signal(SIGCHLD, SIG_IGN);
    nd_init();

    if (argc >= 3) {
        /* single-shot: notify 'Title' 'Body' */
        nd_push(argv[1], argv[2]);
        nd_run();   /* keep alive to animate */
    } else if (argc == 2 && strcmp(argv[1], "--daemon") == 0) {
        /* daemon mode: watch IPC property */
        XSelectInput(nd.dpy, nd.root, PropertyChangeMask);
        nd_run();
    } else {
        /* test notification */
        nd_push("Alpine DE", "Sistema iniciat correctament");
        nd_run();
    }
    return 0;
}
