/*
 * wm.c — Alpine Desktop Environment: Window Manager
 * macOS-style window decorations, focus, snap, keyboard shortcuts
 * Compile: gcc -O2 -o wm wm.c -lX11 -lXext -lXrender -lXft -lfontconfig -lm
 */
#include "../include/common.h"

/* ── Constants ───────────────────────────────────────────────────── */
#define MAX_CLIENTS     256
#define SNAP_THRESHOLD  16
#define MOVE_MASK       (ButtonPressMask|ButtonReleaseMask|PointerMotionMask)

/* ── Structures ──────────────────────────────────────────────────── */
typedef enum { NORMAL, MAXIMIZED, MINIMIZED } WinState;

typedef struct {
    Window  frame;      /* our decoration window */
    Window  client;     /* the actual client window */
    int     x, y;       /* frame position */
    int     w, h;       /* frame size (including titlebar) */
    int     saved_x, saved_y, saved_w, saved_h; /* for unmaximize */
    WinState state;
    char    title[256];
    int     focused;
    /* bounce animation */
    int     bounce;
    int     bounce_y;
    double  bounce_phase;
} Client;

typedef struct {
    Display     *dpy;
    int          screen;
    Window       root;
    int          sw, sh;        /* screen width/height */
    Atoms        atoms;
    Client       clients[MAX_CLIENTS];
    int          nclients;
    int          focused_idx;   /* index into clients[] or -1 */
    /* drag state */
    int          dragging;
    int          drag_start_x, drag_start_y;
    int          drag_frame_x, drag_frame_y;
    int          resizing;
    int          resize_start_x, resize_start_y;
    int          resize_frame_w, resize_frame_h;
    Client      *drag_client;
    /* colors */
    unsigned long col_titlebar, col_titlebar_focused;
    unsigned long col_bg, col_border, col_border_focused;
    unsigned long col_btn_red, col_btn_yellow, col_btn_green;
    unsigned long col_text, col_text_unfocused;
    /* fonts */
    XftFont     *font_title;
    XftColor     xft_text, xft_text_dim;
    /* GC */
    GC           gc;
    /* cursor */
    Cursor       cursor_normal, cursor_move, cursor_resize;
    /* alt+tab */
    int          tab_active;
    int          tab_idx;
} WM;

static WM wm;

/* ── Forward Declarations ────────────────────────────────────────── */
static void wm_init(void);
static void wm_scan_existing(void);
static void wm_run(void);
static Client *wm_find_client(Window w);
static Client *wm_find_frame(Window w);
static void wm_manage(Window w);
static void wm_unmanage(Client *c);
static void wm_focus(Client *c);
static void wm_draw_frame(Client *c);
static void wm_move_resize(Client *c, int x, int y, int w, int h);
static void wm_maximize(Client *c);
static void wm_close(Client *c);
static void wm_snap(Client *c);
static void wm_handle_key(XKeyEvent *e);
static void wm_handle_button(XButtonEvent *e);
static void wm_handle_motion(XMotionEvent *e);
static void wm_handle_map(XMapRequestEvent *e);
static void wm_handle_unmap(XUnmapEvent *e);
static void wm_handle_destroy(XDestroyWindowEvent *e);
static void wm_handle_configure(XConfigureRequestEvent *e);
static void wm_handle_expose(XExposeEvent *e);
static void wm_handle_crossing(XCrossingEvent *e);
static void wm_handle_property(XPropertyEvent *e);
static int  wm_error_handler(Display *d, XErrorEvent *e);
static void wm_update_net_client_list(void);
static void wm_set_active_window(Window w);
static void wm_draw_button(Client *c, int idx);

/* ── Init ─────────────────────────────────────────────────────────── */
static void wm_init(void) {
    wm.dpy = XOpenDisplay(NULL);
    if (!wm.dpy) { fprintf(stderr, "wm: cannot open display\n"); exit(1); }

    XSetErrorHandler(wm_error_handler);

    wm.screen = DefaultScreen(wm.dpy);
    wm.root   = RootWindow(wm.dpy, wm.screen);
    wm.sw     = DisplayWidth(wm.dpy, wm.screen);
    wm.sh     = DisplayHeight(wm.dpy, wm.screen);
    wm.focused_idx = -1;
    wm.nclients    = 0;
    wm.dragging    = 0;
    wm.resizing    = 0;
    wm.tab_active  = 0;

    /* atoms */
    wm.atoms.WM_PROTOCOLS          = XInternAtom(wm.dpy, "WM_PROTOCOLS", False);
    wm.atoms.WM_DELETE_WINDOW      = XInternAtom(wm.dpy, "WM_DELETE_WINDOW", False);
    wm.atoms.WM_STATE              = XInternAtom(wm.dpy, "WM_STATE", False);
    wm.atoms.WM_NAME               = XInternAtom(wm.dpy, "WM_NAME", False);
    wm.atoms.NET_WM_NAME           = XInternAtom(wm.dpy, "_NET_WM_NAME", False);
    wm.atoms.NET_WM_STATE          = XInternAtom(wm.dpy, "_NET_WM_STATE", False);
    wm.atoms.NET_WM_WINDOW_TYPE    = XInternAtom(wm.dpy, "_NET_WM_WINDOW_TYPE", False);
    wm.atoms.NET_WM_WINDOW_TYPE_DOCK   = XInternAtom(wm.dpy, "_NET_WM_WINDOW_TYPE_DOCK", False);
    wm.atoms.NET_WM_WINDOW_TYPE_NORMAL = XInternAtom(wm.dpy, "_NET_WM_WINDOW_TYPE_NORMAL", False);
    wm.atoms.NET_ACTIVE_WINDOW     = XInternAtom(wm.dpy, "_NET_ACTIVE_WINDOW", False);
    wm.atoms.NET_CLIENT_LIST       = XInternAtom(wm.dpy, "_NET_CLIENT_LIST", False);
    wm.atoms.NET_WM_STATE_FULLSCREEN = XInternAtom(wm.dpy, "_NET_WM_STATE_FULLSCREEN", False);
    wm.atoms.NET_WM_STATE_MAXIMIZED_VERT = XInternAtom(wm.dpy, "_NET_WM_STATE_MAXIMIZED_VERT", False);
    wm.atoms.NET_WM_STATE_MAXIMIZED_HORZ = XInternAtom(wm.dpy, "_NET_WM_STATE_MAXIMIZED_HORZ", False);
    wm.atoms.NET_SUPPORTING_WM_CHECK = XInternAtom(wm.dpy, "_NET_SUPPORTING_WM_CHECK", False);

    /* colors */
    wm.col_titlebar         = hex_color(wm.dpy, COLOR_TITLEBAR);
    wm.col_titlebar_focused = hex_color(wm.dpy, 0x2A2D3E);
    wm.col_bg               = hex_color(wm.dpy, COLOR_BG_DARK);
    wm.col_border           = hex_color(wm.dpy, COLOR_BORDER);
    wm.col_border_focused   = hex_color(wm.dpy, COLOR_ACCENT_BLUE);
    wm.col_btn_red          = hex_color(wm.dpy, COLOR_ACCENT_RED);
    wm.col_btn_yellow       = hex_color(wm.dpy, COLOR_ACCENT_YELLOW);
    wm.col_btn_green        = hex_color(wm.dpy, COLOR_ACCENT_GREEN);
    wm.col_text             = hex_color(wm.dpy, COLOR_TEXT_PRIMARY);
    wm.col_text_unfocused   = hex_color(wm.dpy, COLOR_TEXT_SECONDARY);

    /* font */
    wm.font_title = load_font(wm.dpy, wm.screen, FONT_UI_BOLD);
    alloc_xft_color(wm.dpy, wm.screen, COLOR_TEXT_PRIMARY,   &wm.xft_text);
    alloc_xft_color(wm.dpy, wm.screen, COLOR_TEXT_SECONDARY, &wm.xft_text_dim);

    /* GC */
    XGCValues gcv;
    gcv.foreground = wm.col_text;
    gcv.line_width  = BORDER_WIDTH;
    wm.gc = XCreateGC(wm.dpy, wm.root, GCForeground|GCLineWidth, &gcv);

    /* cursors */
    wm.cursor_normal = XCreateFontCursor(wm.dpy, 68);  /* XC_left_ptr */
    wm.cursor_move   = XCreateFontCursor(wm.dpy, 52);  /* XC_fleur */
    wm.cursor_resize = XCreateFontCursor(wm.dpy, 14);  /* XC_bottom_right_corner */

    /* become the WM */
    XSetWindowAttributes wa;
    wa.cursor     = wm.cursor_normal;
    wa.event_mask = SubstructureRedirectMask | SubstructureNotifyMask
                  | ButtonPressMask | KeyPressMask
                  | EnterWindowMask | LeaveWindowMask
                  | FocusChangeMask | PropertyChangeMask
                  | StructureNotifyMask;
    XChangeWindowAttributes(wm.dpy, wm.root, CWCursor|CWEventMask, &wa);

    /* grab Alt+Tab, Alt+F4, Alt+Space, Alt+Return */
    KeyCode kc;
    kc = XKeysymToKeycode(wm.dpy, XK_Tab);
    XGrabKey(wm.dpy, kc, Mod1Mask, wm.root, True, GrabModeAsync, GrabModeAsync);
    kc = XKeysymToKeycode(wm.dpy, XK_F4);
    XGrabKey(wm.dpy, kc, Mod1Mask, wm.root, True, GrabModeAsync, GrabModeAsync);
    kc = XKeysymToKeycode(wm.dpy, XK_space);
    XGrabKey(wm.dpy, kc, Mod1Mask, wm.root, True, GrabModeAsync, GrabModeAsync);
    kc = XKeysymToKeycode(wm.dpy, XK_Return);
    XGrabKey(wm.dpy, kc, Mod1Mask, wm.root, True, GrabModeAsync, GrabModeAsync);
    /* F3 = Shift+Cmd+3 screenshot */
    kc = XKeysymToKeycode(wm.dpy, XK_F3);
    XGrabKey(wm.dpy, kc, Mod1Mask|ShiftMask, wm.root, True, GrabModeAsync, GrabModeAsync);

    /* grab Alt+Button1 for move from anywhere */
    XGrabButton(wm.dpy, 1, Mod1Mask, wm.root, True, MOVE_MASK,
                GrabModeAsync, GrabModeAsync, None, wm.cursor_move);

    /* advertise EWMH support */
    Window wmcheck = XCreateSimpleWindow(wm.dpy, wm.root, 0,0,1,1,0,0,0);
    XChangeProperty(wm.dpy, wmcheck, wm.atoms.NET_SUPPORTING_WM_CHECK,
                    XA_WINDOW, 32, PropModeReplace, (unsigned char*)&wmcheck, 1);
    XChangeProperty(wm.dpy, wm.root, wm.atoms.NET_SUPPORTING_WM_CHECK,
                    XA_WINDOW, 32, PropModeReplace, (unsigned char*)&wmcheck, 1);

    /* set workarea (leave room for topbar and dock) */
    long workarea[4] = { 0, TOPBAR_HEIGHT, wm.sw, wm.sh - TOPBAR_HEIGHT - DOCK_HEIGHT - 4 };
    Atom net_workarea = XInternAtom(wm.dpy, "_NET_WORKAREA", False);
    XChangeProperty(wm.dpy, wm.root, net_workarea, XA_CARDINAL, 32,
                    PropModeReplace, (unsigned char*)workarea, 4);

    /* root background */
    XSetWindowBackground(wm.dpy, wm.root, hex_color(wm.dpy, COLOR_BG_DARK));
    XClearWindow(wm.dpy, wm.root);
    XFlush(wm.dpy);

    wm_scan_existing();
    fprintf(stderr, "wm: started on %dx%d\n", wm.sw, wm.sh);
}

/* ── Scan pre-existing windows ────────────────────────────────────── */
static void wm_scan_existing(void) {
    unsigned int n;
    Window *wins, d1, d2;
    if (!XQueryTree(wm.dpy, wm.root, &d1, &d2, &wins, &n)) return;
    for (unsigned int i = 0; i < n; i++) {
        XWindowAttributes wa;
        if (!XGetWindowAttributes(wm.dpy, wins[i], &wa)) continue;
        if (wa.override_redirect || wa.map_state != IsViewable) continue;
        wm_manage(wins[i]);
    }
    if (wins) XFree(wins);
}

/* ── Find client by client window ─────────────────────────────────── */
static Client *wm_find_client(Window w) {
    for (int i = 0; i < wm.nclients; i++)
        if (wm.clients[i].client == w) return &wm.clients[i];
    return NULL;
}

/* ── Find client by frame window ──────────────────────────────────── */
static Client *wm_find_frame(Window w) {
    for (int i = 0; i < wm.nclients; i++)
        if (wm.clients[i].frame == w) return &wm.clients[i];
    return NULL;
}

/* ── Get window title ─────────────────────────────────────────────── */
static void wm_get_title(Client *c) {
    char *name = NULL;
    Atom type; int fmt; unsigned long n, after;
    unsigned char *data = NULL;

    /* try _NET_WM_NAME first (UTF-8) */
    if (XGetWindowProperty(wm.dpy, c->client, wm.atoms.NET_WM_NAME, 0, 256,
                           False, XInternAtom(wm.dpy, "UTF8_STRING", False),
                           &type, &fmt, &n, &after, &data) == Success && data) {
        name = (char*)data;
    } else {
        XFetchName(wm.dpy, c->client, &name);
    }

    if (name) {
        strncpy(c->title, name, sizeof(c->title)-1);
        c->title[sizeof(c->title)-1] = '\0';
        XFree(name);
    } else {
        strcpy(c->title, "Untitled");
    }
}

/* ── Is dock/panel window ─────────────────────────────────────────── */
static int wm_is_dock(Window w) {
    Atom type; int fmt; unsigned long n, after;
    unsigned char *data = NULL;
    if (XGetWindowProperty(wm.dpy, w, wm.atoms.NET_WM_WINDOW_TYPE, 0, 1,
                           False, XA_ATOM, &type, &fmt, &n, &after, &data)
        == Success && data) {
        Atom win_type = *(Atom*)data;
        XFree(data);
        return win_type == wm.atoms.NET_WM_WINDOW_TYPE_DOCK;
    }
    return 0;
}

/* ── Manage a new window ──────────────────────────────────────────── */
static void wm_manage(Window w) {
    if (wm.nclients >= MAX_CLIENTS) return;
    if (wm_find_client(w)) return; /* already managed */
    if (wm_is_dock(w)) return;     /* don't frame dock/panel */

    XWindowAttributes wa;
    if (!XGetWindowAttributes(wm.dpy, w, &wa)) return;
    if (wa.override_redirect) return;

    Client *c = &wm.clients[wm.nclients];
    memset(c, 0, sizeof(*c));
    c->client = w;
    c->state  = NORMAL;

    /* decide position */
    c->x = wa.x;
    c->y = wa.y < TOPBAR_HEIGHT ? TOPBAR_HEIGHT : wa.y;
    c->w = wa.width  + 2*BORDER_WIDTH;
    c->h = wa.height + TITLEBAR_HEIGHT + BORDER_WIDTH;

    /* cap to screen */
    if (c->x + c->w > wm.sw) c->x = MAX(0, wm.sw - c->w - 20);
    if (c->y + c->h > wm.sh - DOCK_HEIGHT)
        c->y = MAX(TOPBAR_HEIGHT, wm.sh - DOCK_HEIGHT - c->h - 20);

    wm_get_title(c);

    /* create frame */
    XSetWindowAttributes fa;
    fa.background_pixel  = wm.col_titlebar;
    fa.border_pixel      = wm.col_border;
    fa.event_mask        = SubstructureRedirectMask | SubstructureNotifyMask
                         | ButtonPressMask | ButtonReleaseMask
                         | EnterWindowMask | LeaveWindowMask
                         | ExposureMask | FocusChangeMask
                         | PointerMotionMask;
    fa.override_redirect = False;

    c->frame = XCreateWindow(wm.dpy, wm.root,
                             c->x, c->y, c->w, c->h,
                             BORDER_WIDTH, wa.depth,
                             InputOutput, wa.visual,
                             CWBackPixel|CWBorderPixel|CWEventMask|CWOverrideRedirect, &fa);

    /* reparent client into frame */
    XReparentWindow(wm.dpy, w, c->frame, BORDER_WIDTH, TITLEBAR_HEIGHT);
    XResizeWindow(wm.dpy, w, c->w - 2*BORDER_WIDTH, c->h - TITLEBAR_HEIGHT - BORDER_WIDTH);

    /* listen to client */
    XSelectInput(wm.dpy, w, PropertyChangeMask | FocusChangeMask | EnterWindowMask);

    XGrabButton(wm.dpy, 1, 0, c->frame, True, MOVE_MASK,
                GrabModeAsync, GrabModeAsync, None, None);
    XGrabButton(wm.dpy, 3, 0, c->frame, True, MOVE_MASK,
                GrabModeAsync, GrabModeAsync, None, None);

    XMapWindow(wm.dpy, c->frame);
    XMapWindow(wm.dpy, w);

    wm.nclients++;
    wm_update_net_client_list();
    wm_focus(c);
    wm_draw_frame(c);
    XSync(wm.dpy, False);
}

/* ── Unmanage ─────────────────────────────────────────────────────── */
static void wm_unmanage(Client *c) {
    int idx = (int)(c - wm.clients);

    XUnmapWindow(wm.dpy, c->frame);
    XReparentWindow(wm.dpy, c->client, wm.root, c->x, c->y + TITLEBAR_HEIGHT);
    XDestroyWindow(wm.dpy, c->frame);

    /* shift array */
    memmove(&wm.clients[idx], &wm.clients[idx+1],
            (wm.nclients - idx - 1) * sizeof(Client));
    wm.nclients--;

    if (wm.focused_idx >= wm.nclients) wm.focused_idx = wm.nclients - 1;
    if (wm.focused_idx >= 0) wm_focus(&wm.clients[wm.focused_idx]);
    else ipc_set_prop(wm.dpy, IPC_PROP_FOCUS, "");

    wm_update_net_client_list();
}

/* ── Focus ────────────────────────────────────────────────────────── */
static void wm_focus(Client *c) {
    /* unfocus old */
    if (wm.focused_idx >= 0) {
        Client *old = &wm.clients[wm.focused_idx];
        old->focused = 0;
        wm_draw_frame(old);
    }

    wm.focused_idx = (int)(c - wm.clients);
    c->focused = 1;

    XSetInputFocus(wm.dpy, c->client, RevertToPointerRoot, CurrentTime);
    XRaiseWindow(wm.dpy, c->frame);
    wm_draw_frame(c);
    wm_set_active_window(c->client);

    /* update topbar IPC */
    ipc_set_prop(wm.dpy, IPC_PROP_FOCUS, c->title);
}

/* ── Set _NET_ACTIVE_WINDOW ───────────────────────────────────────── */
static void wm_set_active_window(Window w) {
    XChangeProperty(wm.dpy, wm.root, wm.atoms.NET_ACTIVE_WINDOW,
                    XA_WINDOW, 32, PropModeReplace, (unsigned char*)&w, 1);
}

/* ── Update _NET_CLIENT_LIST ──────────────────────────────────────── */
static void wm_update_net_client_list(void) {
    Window wins[MAX_CLIENTS];
    for (int i = 0; i < wm.nclients; i++) wins[i] = wm.clients[i].client;
    XChangeProperty(wm.dpy, wm.root, wm.atoms.NET_CLIENT_LIST,
                    XA_WINDOW, 32, PropModeReplace,
                    (unsigned char*)wins, wm.nclients);
}

/* ── Draw traffic-light button ────────────────────────────────────── */
static void wm_draw_button(Client *c, int idx) {
    /* idx: 0=close(red), 1=minimize(yellow), 2=maximize(green) */
    int bx = BUTTON_MARGIN + idx * (BUTTON_SIZE + 6);
    int by = (TITLEBAR_HEIGHT - BUTTON_SIZE) / 2;

    unsigned long col;
    if (!c->focused) {
        col = hex_color(wm.dpy, 0x585B70); /* greyed out */
    } else {
        switch (idx) {
            case 0: col = wm.col_btn_red;    break;
            case 1: col = wm.col_btn_yellow; break;
            case 2: col = wm.col_btn_green;  break;
            default: col = wm.col_btn_red;   break;
        }
    }

    XSetForeground(wm.dpy, wm.gc, col);
    XFillArc(wm.dpy, c->frame, wm.gc, bx, by, BUTTON_SIZE, BUTTON_SIZE, 0, 360*64);
}

/* ── Draw frame decorations ───────────────────────────────────────── */
static void wm_draw_frame(Client *c) {
    if (!c->frame) return;

    unsigned long bg = c->focused ? wm.col_titlebar_focused : wm.col_titlebar;
    unsigned long border = c->focused ? wm.col_border_focused : wm.col_border;

    XSetWindowBackground(wm.dpy, c->frame, bg);
    XClearWindow(wm.dpy, c->frame);
    XSetWindowBorderWidth(wm.dpy, c->frame, BORDER_WIDTH);
    XSetWindowBorder(wm.dpy, c->frame, border);

    /* traffic light buttons */
    wm_draw_button(c, 0);
    wm_draw_button(c, 1);
    wm_draw_button(c, 2);

    /* title text */
    if (wm.font_title) {
        XftDraw *draw = XftDrawCreate(wm.dpy, c->frame,
                                      DefaultVisual(wm.dpy, wm.screen),
                                      DefaultColormap(wm.dpy, wm.screen));
        if (draw) {
            XftColor *col = c->focused ? &wm.xft_text : &wm.xft_text_dim;
            XGlyphInfo ext;
            XftTextExtentsUtf8(wm.dpy, wm.font_title,
                               (FcChar8*)c->title, strlen(c->title), &ext);
            int tx = (c->w - ext.width) / 2;
            int ty = (TITLEBAR_HEIGHT + wm.font_title->ascent) / 2;
            tx = MAX(tx, BUTTON_MARGIN + 3*(BUTTON_SIZE+6) + 4);
            xft_draw_string(wm.dpy, c->frame, draw, wm.font_title, col, tx, ty, c->title);
            XftDrawDestroy(draw);
        }
    }

    /* separator line below titlebar */
    XSetForeground(wm.dpy, wm.gc, border);
    XDrawLine(wm.dpy, c->frame, wm.gc, 0, TITLEBAR_HEIGHT-1, c->w, TITLEBAR_HEIGHT-1);
}

/* ── Move/resize client + frame ───────────────────────────────────── */
static void wm_move_resize(Client *c, int x, int y, int w, int h) {
    c->x = x; c->y = y; c->w = w; c->h = h;
    XMoveResizeWindow(wm.dpy, c->frame, x, y, w, h);
    XMoveResizeWindow(wm.dpy, c->client,
                      BORDER_WIDTH, TITLEBAR_HEIGHT,
                      w - 2*BORDER_WIDTH, h - TITLEBAR_HEIGHT - BORDER_WIDTH);
}

/* ── Maximize / restore ───────────────────────────────────────────── */
static void wm_maximize(Client *c) {
    if (c->state == MAXIMIZED) {
        wm_move_resize(c, c->saved_x, c->saved_y, c->saved_w, c->saved_h);
        c->state = NORMAL;
    } else {
        c->saved_x = c->x; c->saved_y = c->y;
        c->saved_w = c->w; c->saved_h = c->h;
        int mh = wm.sh - TOPBAR_HEIGHT - DOCK_HEIGHT - 4;
        wm_move_resize(c, 0, TOPBAR_HEIGHT, wm.sw, mh);
        c->state = MAXIMIZED;
    }
    wm_draw_frame(c);
}

/* ── Close window ─────────────────────────────────────────────────── */
static void wm_close(Client *c) {
    /* try WM_DELETE_WINDOW */
    Atom type; int fmt; unsigned long n, after;
    unsigned char *data = NULL;
    int support = 0;
    if (XGetWindowProperty(wm.dpy, c->client, wm.atoms.WM_PROTOCOLS, 0, 32,
                           False, XA_ATOM, &type, &fmt, &n, &after, &data)
        == Success && data) {
        for (unsigned long i = 0; i < n; i++)
            if (((Atom*)data)[i] == wm.atoms.WM_DELETE_WINDOW) { support = 1; break; }
        XFree(data);
    }
    if (support) {
        XEvent ev;
        memset(&ev, 0, sizeof(ev));
        ev.type                 = ClientMessage;
        ev.xclient.window       = c->client;
        ev.xclient.message_type = wm.atoms.WM_PROTOCOLS;
        ev.xclient.format       = 32;
        ev.xclient.data.l[0]    = wm.atoms.WM_DELETE_WINDOW;
        ev.xclient.data.l[1]    = CurrentTime;
        XSendEvent(wm.dpy, c->client, False, NoEventMask, &ev);
    } else {
        XDestroyWindow(wm.dpy, c->client);
    }
}

/* ── Snap to edges ────────────────────────────────────────────────── */
static void wm_snap(Client *c) {
    int work_top    = TOPBAR_HEIGHT;
    int work_bottom = wm.sh - DOCK_HEIGHT - 4;
    int work_h      = work_bottom - work_top;

    /* snap left → left half */
    if (c->x <= SNAP_THRESHOLD) {
        wm_move_resize(c, 0, work_top, wm.sw/2, work_h);
        c->state = NORMAL;
        return;
    }
    /* snap right → right half */
    if (c->x + c->w >= wm.sw - SNAP_THRESHOLD) {
        wm_move_resize(c, wm.sw/2, work_top, wm.sw/2, work_h);
        c->state = NORMAL;
        return;
    }
    /* snap top → maximize */
    if (c->y <= work_top + SNAP_THRESHOLD) {
        wm_maximize(c);
        return;
    }
}

/* ── Hit-test titlebar buttons ────────────────────────────────────── */
static int wm_button_hit(int bx, int by) {
    /* returns 0=close, 1=minimize, 2=maximize, -1=none */
    int ty = (TITLEBAR_HEIGHT - BUTTON_SIZE) / 2;
    if (by < ty || by > ty + BUTTON_SIZE) return -1;
    for (int i = 0; i < 3; i++) {
        int tx = BUTTON_MARGIN + i * (BUTTON_SIZE + 6);
        if (bx >= tx && bx <= tx + BUTTON_SIZE) return i;
    }
    return -1;
}

/* ── Key events ───────────────────────────────────────────────────── */
static void wm_handle_key(XKeyEvent *e) {
    KeySym sym = XkbKeycodeToKeysym(wm.dpy, e->keycode, 0, 0);

    if ((e->state & Mod1Mask) && sym == XK_Tab) {
        /* Alt+Tab: cycle windows */
        if (wm.nclients < 2) return;
        int next = (wm.focused_idx + 1) % wm.nclients;
        wm_focus(&wm.clients[next]);
        return;
    }
    if ((e->state & Mod1Mask) && sym == XK_F4) {
        /* Alt+F4: close focused */
        if (wm.focused_idx >= 0) wm_close(&wm.clients[wm.focused_idx]);
        return;
    }
    if ((e->state & Mod1Mask) && sym == XK_Return) {
        /* Alt+Return: toggle maximize */
        if (wm.focused_idx >= 0) wm_maximize(&wm.clients[wm.focused_idx]);
        return;
    }
    if ((e->state & Mod1Mask) && sym == XK_space) {
        /* Alt+Space: launch spotlight */
        spawn("launcher");
        return;
    }
    if ((e->state & (Mod1Mask|ShiftMask)) && sym == XK_F3) {
        /* Shift+Alt+F3: screenshot */
        spawn("screenshot full");
        return;
    }
}

/* ── Button press ─────────────────────────────────────────────────── */
static void wm_handle_button(XButtonEvent *e) {
    Client *c;

    /* Alt+Button1 on any window: move */
    if (e->state & Mod1Mask && e->button == 1) {
        c = wm_find_client(e->window);
        if (!c) c = wm_find_frame(e->window);
        if (!c) return;
        wm_focus(c);
        wm.dragging     = 1;
        wm.drag_client  = c;
        wm.drag_start_x = e->x_root;
        wm.drag_start_y = e->y_root;
        wm.drag_frame_x = c->x;
        wm.drag_frame_y = c->y;
        XDefineCursor(wm.dpy, wm.root, wm.cursor_move);
        XGrabPointer(wm.dpy, wm.root, True,
                     ButtonReleaseMask | PointerMotionMask,
                     GrabModeAsync, GrabModeAsync, None, wm.cursor_move, CurrentTime);
        return;
    }

    /* click on frame */
    c = wm_find_frame(e->window);
    if (c) {
        wm_focus(c);

        if (e->y < TITLEBAR_HEIGHT) {
            int btn = wm_button_hit(e->x, e->y);
            if (btn == 0) { wm_close(c); return; }
            if (btn == 1) { XIconifyWindow(wm.dpy, c->client, wm.screen); return; }
            if (btn == 2) { wm_maximize(c); return; }

            /* double-click titlebar → maximize */
            if (e->button == 1) {
                /* start drag */
                wm.dragging     = 1;
                wm.drag_client  = c;
                wm.drag_start_x = e->x_root;
                wm.drag_start_y = e->y_root;
                wm.drag_frame_x = c->x;
                wm.drag_frame_y = c->y;
                XDefineCursor(wm.dpy, wm.root, wm.cursor_move);
                XGrabPointer(wm.dpy, wm.root, True,
                             ButtonReleaseMask | PointerMotionMask,
                             GrabModeAsync, GrabModeAsync, None, wm.cursor_move, CurrentTime);
            }
        } else if (e->button == 1) {
            /* bottom-right resize zone */
            if (e->x > c->w - 16 && e->y > c->h - 16) {
                wm.resizing       = 1;
                wm.drag_client    = c;
                wm.resize_start_x = e->x_root;
                wm.resize_start_y = e->y_root;
                wm.resize_frame_w = c->w;
                wm.resize_frame_h = c->h;
                XGrabPointer(wm.dpy, wm.root, True,
                             ButtonReleaseMask | PointerMotionMask,
                             GrabModeAsync, GrabModeAsync, None, wm.cursor_resize, CurrentTime);
            }
        }
        return;
    }

    /* click on client */
    c = wm_find_client(e->window);
    if (c) { wm_focus(c); XAllowEvents(wm.dpy, ReplayPointer, CurrentTime); }
}

/* ── Mouse motion ─────────────────────────────────────────────────── */
static void wm_handle_motion(XMotionEvent *e) {
    if (wm.dragging && wm.drag_client) {
        int nx = wm.drag_frame_x + (e->x_root - wm.drag_start_x);
        int ny = wm.drag_frame_y + (e->y_root - wm.drag_start_y);
        /* clamp: keep titlebar visible */
        ny = MAX(ny, TOPBAR_HEIGHT);
        XMoveWindow(wm.dpy, wm.drag_client->frame, nx, ny);
        wm.drag_client->x = nx;
        wm.drag_client->y = ny;
    }
    if (wm.resizing && wm.drag_client) {
        int nw = wm.resize_frame_w + (e->x_root - wm.resize_start_x);
        int nh = wm.resize_frame_h + (e->y_root - wm.resize_start_y);
        nw = MAX(nw, 200);
        nh = MAX(nh, TITLEBAR_HEIGHT + 80);
        wm_move_resize(wm.drag_client,
                       wm.drag_client->x, wm.drag_client->y, nw, nh);
    }
}

/* ── Button release ───────────────────────────────────────────────── */
static void wm_handle_button_release(XButtonEvent *e) {
    (void)e;
    if (wm.dragging) {
        if (wm.drag_client) wm_snap(wm.drag_client);
        wm.dragging    = 0;
        wm.drag_client = NULL;
        XDefineCursor(wm.dpy, wm.root, wm.cursor_normal);
        XUngrabPointer(wm.dpy, CurrentTime);
    }
    if (wm.resizing) {
        wm.resizing    = 0;
        wm.drag_client = NULL;
        XUngrabPointer(wm.dpy, CurrentTime);
    }
}

/* ── MapRequest ───────────────────────────────────────────────────── */
static void wm_handle_map(XMapRequestEvent *e) {
    XWindowAttributes wa;
    if (!XGetWindowAttributes(wm.dpy, e->window, &wa)) return;
    if (wa.override_redirect) { XMapWindow(wm.dpy, e->window); return; }
    wm_manage(e->window);
}

/* ── UnmapNotify ──────────────────────────────────────────────────── */
static void wm_handle_unmap(XUnmapEvent *e) {
    Client *c = wm_find_client(e->window);
    if (c) wm_unmanage(c);
}

/* ── DestroyNotify ────────────────────────────────────────────────── */
static void wm_handle_destroy(XDestroyWindowEvent *e) {
    Client *c = wm_find_client(e->window);
    if (!c) c = wm_find_frame(e->window);
    if (c) wm_unmanage(c);
}

/* ── ConfigureRequest ─────────────────────────────────────────────── */
static void wm_handle_configure(XConfigureRequestEvent *e) {
    Client *c = wm_find_client(e->window);
    if (c) {
        /* honour requested size, update frame */
        int nw = (e->value_mask & CWWidth)  ? e->width  : (c->w - 2*BORDER_WIDTH);
        int nh = (e->value_mask & CWHeight) ? e->height : (c->h - TITLEBAR_HEIGHT - BORDER_WIDTH);
        c->w = nw + 2*BORDER_WIDTH;
        c->h = nh + TITLEBAR_HEIGHT + BORDER_WIDTH;
        XMoveResizeWindow(wm.dpy, c->frame, c->x, c->y, c->w, c->h);
        XMoveResizeWindow(wm.dpy, c->client, BORDER_WIDTH, TITLEBAR_HEIGHT, nw, nh);
    } else {
        XWindowChanges wc;
        wc.x = e->x; wc.y = e->y; wc.width = e->width; wc.height = e->height;
        wc.border_width = e->border_width;
        wc.sibling      = e->above;
        wc.stack_mode   = e->detail;
        XConfigureWindow(wm.dpy, e->window, e->value_mask, &wc);
    }
}

/* ── Expose ───────────────────────────────────────────────────────── */
static void wm_handle_expose(XExposeEvent *e) {
    if (e->count > 0) return;
    Client *c = wm_find_frame(e->window);
    if (c) wm_draw_frame(c);
}

/* ── EnterNotify (focus-follows-pointer) ──────────────────────────── */
static void wm_handle_crossing(XCrossingEvent *e) {
    if (e->type != EnterNotify) return;
    if (e->mode != NotifyNormal) return;
    Client *c = wm_find_frame(e->window);
    if (!c) c = wm_find_client(e->window);
    if (c && !c->focused) wm_focus(c);
}

/* ── PropertyNotify (title update) ───────────────────────────────── */
static void wm_handle_property(XPropertyEvent *e) {
    Client *c = wm_find_client(e->window);
    if (!c) return;
    if (e->atom == wm.atoms.NET_WM_NAME || e->atom == wm.atoms.WM_NAME) {
        wm_get_title(c);
        wm_draw_frame(c);
        if (c->focused) ipc_set_prop(wm.dpy, IPC_PROP_FOCUS, c->title);
    }
}

/* ── Error handler (ignore) ───────────────────────────────────────── */
static int wm_error_handler(Display *d, XErrorEvent *e) {
    char buf[256];
    XGetErrorText(d, e->error_code, buf, sizeof(buf));
    fprintf(stderr, "wm: X error: %s (req %d)\n", buf, e->request_code);
    return 0;
}

/* ── Main event loop ──────────────────────────────────────────────── */
static void wm_run(void) {
    XEvent ev;
    for (;;) {
        XNextEvent(wm.dpy, &ev);
        switch (ev.type) {
            case KeyPress:          wm_handle_key(&ev.xkey);             break;
            case ButtonPress:       wm_handle_button(&ev.xbutton);       break;
            case ButtonRelease:     wm_handle_button_release(&ev.xbutton); break;
            case MotionNotify:
                while (XCheckTypedEvent(wm.dpy, MotionNotify, &ev));
                wm_handle_motion(&ev.xmotion);
                break;
            case MapRequest:        wm_handle_map(&ev.xmaprequest);      break;
            case UnmapNotify:       wm_handle_unmap(&ev.xunmap);         break;
            case DestroyNotify:     wm_handle_destroy(&ev.xdestroywindow); break;
            case ConfigureRequest:  wm_handle_configure(&ev.xconfigurerequest); break;
            case Expose:            wm_handle_expose(&ev.xexpose);       break;
            case EnterNotify:       wm_handle_crossing(&ev.xcrossing);   break;
            case PropertyNotify:    wm_handle_property(&ev.xproperty);   break;
            default: break;
        }
    }
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(void) {
    signal(SIGCHLD, SIG_IGN);
    wm_init();
    wm_run();
    return 0;
}
