/*
 * launcher.c — Alpine Desktop Environment: Spotlight-style Launcher
 * Alt+Space: centred search bar → expands with results
 * Compile: gcc -O2 -o launcher launcher.c -lX11 -lXft -lfontconfig -lm
 */
#include "../include/common.h"
#include <ctype.h>

/* ── Constants ───────────────────────────────────────────────────── */
#define LAUNCHER_W      520
#define LAUNCHER_H_MIN  56
#define LAUNCHER_H_MAX  360
#define INPUT_H         56
#define RESULT_H        48
#define MAX_RESULTS     32
#define MAX_APPS        512
#define PADDING         14
#define ICON_SZ         32

/* ── Result entry ─────────────────────────────────────────────────── */
typedef struct {
    char name[128];
    char desc[256];
    char exec[256];
    int  is_cmd;
} Result;

/* ── App entry (from .desktop files) ─────────────────────────────── */
typedef struct {
    char name[128];
    char exec[256];
    char comment[256];
} App;

/* ── Launcher state ──────────────────────────────────────────────── */
typedef struct {
    Display  *dpy;
    int       screen;
    Window    root, win;
    int       sw, sh;
    GC        gc;
    XftFont  *font_input;
    XftFont  *font_name;
    XftFont  *font_desc;
    XftColor  col_text, col_text_dim, col_accent, col_bg_item;
    /* colors */
    unsigned long col_bg, col_border, col_sel, col_cursor;
    /* state */
    char      query[256];
    int       query_len;
    int       cursor_pos;
    Result    results[MAX_RESULTS];
    int       nresults;
    int       selected;
    int       visible;
    /* apps */
    App       apps[MAX_APPS];
    int       napps;
    /* cursor blink */
    int       cursor_blink;
    /* system commands */
    const char *syscmds[64];
    int        nsyscmds;
} Launcher;

static Launcher la;

/* ── Forward declarations ────────────────────────────────────────── */
static void la_init(void);
static void la_show(void);
static void la_hide(void);
static void la_run(void);
static void la_draw(void);
static void la_search(void);
static void la_execute(int idx);
static void la_load_apps(void);
static void la_handle_key(XKeyEvent *e);
static void la_handle_expose(void);
static void la_handle_focusout(void);

/* ── Helpers ─────────────────────────────────────────────────────── */
static int str_icontains(const char *haystack, const char *needle) {
    if (!haystack || !needle || !*needle) return 1;
    char h[512], n[256];
    for (int i = 0; haystack[i]; i++) h[i] = tolower((unsigned char)haystack[i]);
    h[strlen(haystack)] = '\0';
    for (int i = 0; needle[i]; i++) n[i] = tolower((unsigned char)needle[i]);
    n[strlen(needle)] = '\0';
    return strstr(h, n) != NULL;
}

/* ── Parse one .desktop file ──────────────────────────────────────── */
static void la_parse_desktop(const char *path) {
    if (la.napps >= MAX_APPS) return;
    FILE *f = fopen(path, "r");
    if (!f) return;

    App app; memset(&app, 0, sizeof(app));
    char line[512];
    int in_desktop = 0;

    while (fgets(line, sizeof(line), f)) {
        /* strip newline */
        int len = strlen(line);
        while (len > 0 && (line[len-1] == '\n' || line[len-1] == '\r')) line[--len] = '\0';

        if (strcmp(line, "[Desktop Entry]") == 0) { in_desktop = 1; continue; }
        if (line[0] == '[' && in_desktop) break; /* next section */
        if (!in_desktop) continue;

        if (strncmp(line, "Name=", 5) == 0 && !app.name[0])
            strncpy(app.name, line+5, sizeof(app.name)-1);
        else if (strncmp(line, "Exec=", 5) == 0 && !app.exec[0]) {
            strncpy(app.exec, line+5, sizeof(app.exec)-1);
            /* strip %U %f etc. */
            char *pct = strchr(app.exec, '%');
            if (pct) { while (pct > app.exec && *(pct-1) == ' ') pct--;  *pct = '\0'; }
        }
        else if (strncmp(line, "Comment=", 8) == 0 && !app.comment[0])
            strncpy(app.comment, line+8, sizeof(app.comment)-1);
        else if (strncmp(line, "NoDisplay=true", 14) == 0) {
            fclose(f);
            return; /* skip hidden apps */
        }
    }
    fclose(f);
    if (app.name[0] && app.exec[0])
        la.apps[la.napps++] = app;
}

/* ── Load all .desktop files ──────────────────────────────────────── */
static void la_load_apps(void) {
    static const char *dirs[] = {
        "/usr/share/applications",
        "/usr/local/share/applications",
        NULL
    };
    for (int d = 0; dirs[d]; d++) {
        DIR *dir = opendir(dirs[d]);
        if (!dir) continue;
        struct dirent *ent;
        while ((ent = readdir(dir))) {
            int nl = strlen(ent->d_name);
            if (nl < 8 || strcmp(ent->d_name + nl - 8, ".desktop")) continue;
            char path[512];
            snprintf(path, sizeof(path), "%s/%s", dirs[d], ent->d_name);
            la_parse_desktop(path);
        }
        closedir(dir);
    }

    /* fallback built-in apps if no .desktop found */
    if (la.napps == 0) {
        static App fallback[] = {
            { "Terminal",   "xterm",   "Emulador de terminal" },
            { "Firefox",    "firefox", "Navegador web" },
            { "Files",      "thunar",  "Gestor de fitxers" },
            { "Text Editor","gedit",   "Editor de text" },
            { "Settings",   "xterm -e vi ~/.config/de/config", "Configuració" },
        };
        for (int i = 0; i < (int)ARRLEN(fallback); i++)
            la.apps[la.napps++] = fallback[i];
    }

    fprintf(stderr, "launcher: loaded %d apps\n", la.napps);
}

/* ── Search ───────────────────────────────────────────────────────── */
static void la_search(void) {
    la.nresults = 0;
    if (!la.query[0]) return;

    /* apps first */
    for (int i = 0; i < la.napps && la.nresults < MAX_RESULTS; i++) {
        if (str_icontains(la.apps[i].name, la.query) ||
            str_icontains(la.apps[i].comment, la.query)) {
            Result *r = &la.results[la.nresults++];
            strncpy(r->name, la.apps[i].name, sizeof(r->name)-1);
            strncpy(r->desc, la.apps[i].comment[0] ? la.apps[i].comment : "Aplicació",
                    sizeof(r->desc)-1);
            strncpy(r->exec, la.apps[i].exec, sizeof(r->exec)-1);
            r->is_cmd = 0;
        }
    }

    /* system commands */
    for (int i = 0; i < la.nsyscmds && la.nresults < MAX_RESULTS; i++) {
        if (str_icontains(la.syscmds[i], la.query)) {
            Result *r = &la.results[la.nresults++];
            strncpy(r->name, la.syscmds[i], sizeof(r->name)-1);
            strcpy(r->desc, "Comanda del sistema");
            strncpy(r->exec, la.syscmds[i], sizeof(r->exec)-1);
            r->is_cmd = 1;
        }
    }

    /* if query looks like a command, add it directly */
    if (la.nresults < MAX_RESULTS) {
        Result *r = &la.results[la.nresults++];
        snprintf(r->name, sizeof(r->name), "Executar: %s", la.query);
        strcpy(r->desc, "Executar comanda directament");
        strncpy(r->exec, la.query, sizeof(r->exec)-1);
        r->is_cmd = 1;
    }

    if (la.selected >= la.nresults) la.selected = 0;
}

/* ── Execute selected ─────────────────────────────────────────────── */
static void la_execute(int idx) {
    if (idx < 0 || idx >= la.nresults) return;
    spawn(la.results[idx].exec);
    la_hide();
}

/* ── Resize window to fit results ─────────────────────────────────── */
static void la_resize(void) {
    int h = INPUT_H;
    if (la.nresults > 0) {
        int rh = MIN(la.nresults, 6) * RESULT_H;
        h += rh + PADDING;
    }
    h = MIN(h, LAUNCHER_H_MAX);
    int ly = (la.sh - h) / 2;
    XMoveResizeWindow(la.dpy, la.win,
                      (la.sw - LAUNCHER_W) / 2, ly, LAUNCHER_W, h);
}

/* ── Draw ─────────────────────────────────────────────────────────── */
static void la_draw(void) {
    if (!la.visible) return;

    int W = LAUNCHER_W;

    /* background */
    XSetForeground(la.dpy, la.gc, la.col_bg);
    draw_rounded_rect(la.dpy, la.win, la.gc, 0, 0, W, INPUT_H, 12);

    /* input area border */
    XSetForeground(la.dpy, la.gc, la.col_border);
    XDrawRectangle(la.dpy, la.win, la.gc, 0, 0, W-1, INPUT_H-1);

    /* search icon */
    if (la.font_input) {
        XftDraw *draw = XftDrawCreate(la.dpy, la.win,
                                      DefaultVisual(la.dpy, la.screen),
                                      DefaultColormap(la.dpy, la.screen));
        /* magnifier */
        XftColor dim;
        alloc_xft_color(la.dpy, la.screen, COLOR_TEXT_SECONDARY, &dim);
        XftDrawStringUtf8(draw, &dim, la.font_input, PADDING,
                          (INPUT_H + la.font_input->ascent) / 2,
                          (FcChar8*)"🔍", strlen("🔍"));
        XftColorFree(la.dpy, DefaultVisual(la.dpy, la.screen),
                     DefaultColormap(la.dpy, la.screen), &dim);

        /* query text */
        int tx = PADDING + 28;
        int ty = (INPUT_H + la.font_input->ascent) / 2;
        XftDrawStringUtf8(draw, &la.col_text, la.font_input, tx, ty,
                          (FcChar8*)la.query, la.query_len);

        /* cursor blink */
        if (la.cursor_blink % 16 < 8) {
            XGlyphInfo ext;
            XftTextExtentsUtf8(la.dpy, la.font_input,
                               (FcChar8*)la.query, la.query_len, &ext);
            XSetForeground(la.dpy, la.gc, la.col_cursor);
            XFillRectangle(la.dpy, la.win, la.gc,
                           tx + ext.xOff + 1, ty - la.font_input->ascent,
                           2, la.font_input->ascent + la.font_input->descent);
        }

        /* results */
        if (la.nresults > 0) {
            /* separator */
            XSetForeground(la.dpy, la.gc, la.col_border);
            XDrawLine(la.dpy, la.win, la.gc, 0, INPUT_H, W, INPUT_H);

            int max_show = MIN(la.nresults, 6);
            for (int i = 0; i < max_show; i++) {
                int ry = INPUT_H + i * RESULT_H;
                Result *r = &la.results[i];

                /* selection highlight */
                if (i == la.selected) {
                    XSetForeground(la.dpy, la.gc, la.col_sel);
                    XFillRectangle(la.dpy, la.win, la.gc, 0, ry, W, RESULT_H);
                }

                /* icon placeholder (colored circle) */
                unsigned long ic = r->is_cmd ?
                    hex_color(la.dpy, COLOR_ACCENT_GREEN) :
                    hex_color(la.dpy, COLOR_ACCENT_BLUE);
                XSetForeground(la.dpy, la.gc, ic);
                XFillArc(la.dpy, la.win, la.gc,
                         PADDING, ry + (RESULT_H - ICON_SZ)/2,
                         ICON_SZ, ICON_SZ, 0, 360*64);

                /* icon letter */
                char letter[4] = { r->name[0], '\0' };
                XftColor white;
                alloc_xft_color(la.dpy, la.screen, COLOR_WHITE, &white);
                XGlyphInfo iext;
                XftTextExtentsUtf8(la.dpy, la.font_name, (FcChar8*)letter, 1, &iext);
                int ix = PADDING + (ICON_SZ - iext.xOff)/2;
                int iy = ry + (RESULT_H + la.font_name->ascent)/2 - 2;
                XftDrawStringUtf8(draw, &white, la.font_name, ix, iy,
                                  (FcChar8*)letter, 1);
                XftColorFree(la.dpy, DefaultVisual(la.dpy, la.screen),
                             DefaultColormap(la.dpy, la.screen), &white);

                /* name */
                int nx = PADDING + ICON_SZ + 10;
                int ny = ry + (RESULT_H/2);
                XftDrawStringUtf8(draw, &la.col_text, la.font_name,
                                  nx, ny, (FcChar8*)r->name, strlen(r->name));

                /* description */
                int dy = ry + RESULT_H - 10;
                XftDrawStringUtf8(draw, &la.col_text_dim, la.font_desc,
                                  nx, dy, (FcChar8*)r->desc, strlen(r->desc));
            }
        }

        XftDrawDestroy(draw);
    }

    /* bottom border if results */
    if (la.nresults > 0) {
        XSetForeground(la.dpy, la.gc, la.col_border);
        int h = INPUT_H + MIN(la.nresults,6) * RESULT_H + PADDING;
        XDrawRectangle(la.dpy, la.win, la.gc, 0, 0, W-1, h-1);
    }

    XFlush(la.dpy);
}

/* ── Show ─────────────────────────────────────────────────────────── */
static void la_show(void) {
    la.query[0]  = '\0';
    la.query_len = 0;
    la.nresults  = 0;
    la.selected  = 0;
    la.visible   = 1;
    la_resize();
    XMapRaised(la.dpy, la.win);
    XSetInputFocus(la.dpy, la.win, RevertToPointerRoot, CurrentTime);
    XFlush(la.dpy);
}

/* ── Hide ─────────────────────────────────────────────────────────── */
static void la_hide(void) {
    la.visible = 0;
    XUnmapWindow(la.dpy, la.win);
    XFlush(la.dpy);
}

/* ── Key handler ──────────────────────────────────────────────────── */
static void la_handle_key(XKeyEvent *e) {
    KeySym sym;
    char buf[32];
    int len = XLookupString(e, buf, sizeof(buf)-1, &sym, NULL);
    buf[len] = '\0';

    switch (sym) {
        case XK_Escape:
            la_hide();
            return;
        case XK_Return:
        case XK_KP_Enter:
            la_execute(la.selected);
            return;
        case XK_Up:
            if (la.selected > 0) la.selected--;
            break;
        case XK_Down:
            if (la.selected < la.nresults - 1) la.selected++;
            break;
        case XK_BackSpace:
            if (la.query_len > 0) {
                /* UTF-8 aware backspace */
                la.query_len--;
                while (la.query_len > 0 && (la.query[la.query_len] & 0xC0) == 0x80)
                    la.query_len--;
                la.query[la.query_len] = '\0';
                la.selected = 0;
                la_search();
                la_resize();
            }
            break;
        case XK_Delete:
            la.query[0] = '\0';
            la.query_len = 0;
            la.nresults  = 0;
            la.selected  = 0;
            la_resize();
            break;
        case XK_Tab:
            if (la.nresults > 0) la.selected = (la.selected+1) % la.nresults;
            break;
        default:
            if (len > 0 && buf[0] >= 0x20) {
                if (la.query_len + len < (int)sizeof(la.query) - 1) {
                    memcpy(la.query + la.query_len, buf, len);
                    la.query_len += len;
                    la.query[la.query_len] = '\0';
                    la.selected = 0;
                    la_search();
                    la_resize();
                }
            }
            break;
    }
    la_draw();
}

/* ── Init ─────────────────────────────────────────────────────────── */
static void la_init(void) {
    la.dpy    = XOpenDisplay(NULL);
    if (!la.dpy) { fprintf(stderr, "launcher: cannot open display\n"); exit(1); }
    la.screen = DefaultScreen(la.dpy);
    la.root   = RootWindow(la.dpy, la.screen);
    la.sw     = DisplayWidth(la.dpy, la.screen);
    la.sh     = DisplayHeight(la.dpy, la.screen);
    la.visible    = 0;
    la.cursor_blink = 0;

    /* colors */
    la.col_bg     = hex_color(la.dpy, 0x1E2030);
    la.col_border = hex_color(la.dpy, COLOR_BORDER);
    la.col_sel    = hex_color(la.dpy, COLOR_SELECTION);
    la.col_cursor = hex_color(la.dpy, COLOR_ACCENT_BLUE);

    alloc_xft_color(la.dpy, la.screen, COLOR_TEXT_PRIMARY,   &la.col_text);
    alloc_xft_color(la.dpy, la.screen, COLOR_TEXT_SECONDARY, &la.col_text_dim);
    alloc_xft_color(la.dpy, la.screen, COLOR_ACCENT_BLUE,    &la.col_accent);
    alloc_xft_color(la.dpy, la.screen, COLOR_SELECTION,      &la.col_bg_item);

    la.font_input = load_font(la.dpy, la.screen, "SF Pro Display:size=16");
    la.font_name  = load_font(la.dpy, la.screen, FONT_UI_BOLD);
    la.font_desc  = load_font(la.dpy, la.screen, FONT_UI_SMALL);

    /* system commands list */
    static const char *cmds[] = {
        "ls","cat","grep","find","ps","top","htop","df","du","free",
        "kill","pkill","ping","curl","wget","git","vim","nano","ssh",
        "cp","mv","rm","mkdir","chmod","chown","tar","zip","unzip",NULL
    };
    la.nsyscmds = 0;
    for (int i = 0; cmds[i]; i++) la.syscmds[la.nsyscmds++] = cmds[i];

    /* create launcher window (initially unmapped) */
    XSetWindowAttributes wa;
    wa.background_pixel  = la.col_bg;
    wa.border_pixel      = la.col_border;
    wa.override_redirect = True;
    wa.event_mask        = ExposureMask | KeyPressMask
                         | ButtonPressMask | FocusChangeMask;

    la.win = XCreateWindow(la.dpy, la.root,
                           (la.sw - LAUNCHER_W)/2,
                           (la.sh - LAUNCHER_H_MIN)/2,
                           LAUNCHER_W, LAUNCHER_H_MIN, 1,
                           DefaultDepth(la.dpy, la.screen),
                           InputOutput,
                           DefaultVisual(la.dpy, la.screen),
                           CWBackPixel|CWBorderPixel|CWOverrideRedirect|CWEventMask, &wa);

    la.gc = XCreateGC(la.dpy, la.win, 0, NULL);

    /* grab Alt+Space globally */
    KeyCode kc = XKeysymToKeycode(la.dpy, XK_space);
    XGrabKey(la.dpy, kc, Mod1Mask, la.root, True, GrabModeAsync, GrabModeAsync);

    XSelectInput(la.dpy, la.root, KeyPressMask);

    la_load_apps();

    /* show immediately if no args; otherwise wait for hotkey */
    la_show();
}

/* ── Main loop ────────────────────────────────────────────────────── */
static void la_run(void) {
    XEvent ev;
    struct timespec ts = { 0, 30 * 1000000L }; /* 30ms */

    while (1) {
        while (XPending(la.dpy)) {
            XNextEvent(la.dpy, &ev);
            switch (ev.type) {
                case KeyPress:
                    if (ev.xkey.window == la.root) {
                        KeySym sym = XkbKeycodeToKeysym(la.dpy, ev.xkey.keycode, 0, 0);
                        if (sym == XK_space && (ev.xkey.state & Mod1Mask)) {
                            if (la.visible) la_hide(); else la_show();
                        }
                    } else {
                        la_handle_key(&ev.xkey);
                    }
                    break;
                case Expose:
                    if (ev.xexpose.count == 0) la_draw();
                    break;
                case FocusOut:
                    la_hide();
                    break;
                case ButtonPress:
                    /* click outside = hide */
                    if (ev.xbutton.window != la.win) la_hide();
                    else {
                        /* click on result */
                        int ry = ev.xbutton.y - INPUT_H;
                        if (ry >= 0 && la.nresults > 0) {
                            int idx = ry / RESULT_H;
                            if (idx < la.nresults) la_execute(idx);
                        }
                    }
                    break;
                default: break;
            }
        }
        la.cursor_blink++;
        if (la.visible) la_draw();
        nanosleep(&ts, NULL);
    }
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(void) {
    signal(SIGCHLD, SIG_IGN);
    la_init();
    la_run();
    return 0;
}
