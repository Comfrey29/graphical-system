/*
 * dock.c — Alpine Desktop Environment: Dock
 * macOS-style dock: zoom, bounce, open indicators, drag reorder, context menu
 * Compile: gcc -O2 -o dock dock.c -lX11 -lXft -lfontconfig -lm
 */
#include "../include/common.h"

/* ── Constants ───────────────────────────────────────────────────── */
#define MAX_ICONS       16
#define BOUNCE_FRAMES   24      /* frames per bounce cycle */
#define BOUNCE_CYCLES   3
#define BOUNCE_AMP      18      /* pixels of bounce amplitude */
#define ZOOM_SPEED      0.18    /* lerp speed for zoom */
#define DOT_RADIUS      3
#define TOOLTIP_H       24
#define CTX_ITEM_H      24
#define CTX_WIDTH       140

/* ── Icon entry ──────────────────────────────────────────────────── */
typedef struct {
    const char *name;
    const char *exec;
    const char *icon_name;      /* xpm/text fallback */
    unsigned long icon_color;   /* placeholder color */
    int    open;                /* is running? */
    int    bounce_frame;        /* >0 = bouncing */
    double cur_size;            /* current rendered size (zoom anim) */
    double target_size;         /* target size */
    /* drag */
    int    drag;
} DockIcon;

static DockIcon icons[] = {
    { "Finder",    "thunar",   "folder",  0x89B4FA, 0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, 0 },
    { "Terminal",  "xterm",    "terminal",0xA6E3A1, 0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, 0 },
    { "Firefox",   "firefox",  "firefox", 0xFAB387, 0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, 0 },
    { "Editor",    "xterm -e vim","vim",  0xF38BA8, 0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, 0 },
    { "Paperera",  NULL,       "trash",   0x585B70, 0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, 0 },
};
#define N_ICONS ((int)ARRLEN(icons))

/* ── Dock state ──────────────────────────────────────────────────── */
typedef struct {
    Display      *dpy;
    int           screen;
    Window        root, win;
    int           sw, sh;
    GC            gc;
    XftFont      *font;
    XftColor      col_text, col_dot;
    /* geometry */
    int           dock_y;       /* top of dock */
    int           dock_x;       /* left of dock panel */
    int           dock_w;       /* width of dock panel */
    /* interaction */
    int           mouse_x;
    int           hover_idx;    /* icon under cursor */
    /* drag state */
    int           dragging;
    int           drag_idx;
    int           drag_off_x;   /* cursor offset in icon */
    int           drag_cur_x;   /* current drag x */
    /* context menu */
    int           ctx_open;
    int           ctx_idx;      /* which icon */
    Window        ctx_win;
    int           ctx_hover;
    /* tooltip */
    int           tooltip_show;
    int           tooltip_idx;
    Window        tooltip_win;
    /* colors */
    unsigned long col_bg, col_border, col_btn_bg;
    /* running */
    int           running;
} Dock;

static Dock dk;

/* ── Forward declarations ────────────────────────────────────────── */
static void dock_init(void);
static void dock_run(void);
static void dock_draw(void);
static void dock_draw_icon(int idx, int ix, int iy, int sz);
static void dock_draw_ctx(void);
static void dock_draw_tooltip(int idx);
static void dock_calc_geometry(int *xs, int *sizes);
static void dock_handle_button(XButtonEvent *e);
static void dock_handle_motion(XMotionEvent *e);
static void dock_handle_release(XButtonEvent *e);
static void dock_handle_expose(void);
static void dock_open_ctx(int idx, int rx, int ry);
static void dock_close_ctx(void);
static void dock_launch(int idx);
static void dock_bounce(int idx);
static void dock_update_bounce(void);
static void dock_update_zoom(void);

/* ── Init ─────────────────────────────────────────────────────────── */
static void dock_init(void) {
    dk.dpy    = XOpenDisplay(NULL);
    if (!dk.dpy) { fprintf(stderr, "dock: cannot open display\n"); exit(1); }
    dk.screen = DefaultScreen(dk.dpy);
    dk.root   = RootWindow(dk.dpy, dk.screen);
    dk.sw     = DisplayWidth(dk.dpy, dk.screen);
    dk.sh     = DisplayHeight(dk.dpy, dk.screen);
    dk.running   = 1;
    dk.hover_idx = -1;
    dk.dragging  = 0;
    dk.drag_idx  = -1;
    dk.ctx_open  = 0;
    dk.ctx_win   = None;
    dk.ctx_hover = -1;
    dk.tooltip_show = 0;
    dk.tooltip_win  = None;
    dk.mouse_x = -1;

    /* colors */
    dk.col_bg     = hex_color(dk.dpy, COLOR_DOCK_BG);
    dk.col_border = hex_color(dk.dpy, COLOR_BORDER);
    dk.col_btn_bg = hex_color(dk.dpy, COLOR_HOVER);

    alloc_xft_color(dk.dpy, dk.screen, COLOR_TEXT_PRIMARY,  &dk.col_text);
    alloc_xft_color(dk.dpy, dk.screen, COLOR_ACCENT_BLUE,   &dk.col_dot);

    dk.font = load_font(dk.dpy, dk.screen, FONT_UI_SMALL);

    /* calculate dock geometry */
    int total_w = N_ICONS * (DOCK_ICON_SIZE + DOCK_PADDING) + DOCK_PADDING;
    dk.dock_w = MIN(total_w, DOCK_MAX_WIDTH);
    dk.dock_x = (dk.sw - dk.dock_w) / 2;
    dk.dock_y = dk.sh - DOCK_HEIGHT - 4;

    /* create dock window */
    XSetWindowAttributes wa;
    wa.background_pixel  = dk.col_bg;
    wa.border_pixel      = dk.col_border;
    wa.override_redirect = True;
    wa.event_mask        = ExposureMask | ButtonPressMask | ButtonReleaseMask
                         | PointerMotionMask | EnterWindowMask | LeaveWindowMask;

    dk.win = XCreateWindow(dk.dpy, dk.root,
                           dk.dock_x, dk.dock_y,
                           dk.dock_w, DOCK_HEIGHT + 4,
                           1,
                           DefaultDepth(dk.dpy, dk.screen),
                           InputOutput,
                           DefaultVisual(dk.dpy, dk.screen),
                           CWBackPixel|CWBorderPixel|CWOverrideRedirect|CWEventMask, &wa);

    /* EWMH dock type */
    Atom dock_type = XInternAtom(dk.dpy, "_NET_WM_WINDOW_TYPE_DOCK", False);
    Atom type_atom = XInternAtom(dk.dpy, "_NET_WM_WINDOW_TYPE", False);
    XChangeProperty(dk.dpy, dk.win, type_atom, XA_ATOM, 32,
                    PropModeReplace, (unsigned char*)&dock_type, 1);

    /* strut: reserve bottom */
    long strut[12] = {0};
    strut[3] = DOCK_HEIGHT + 4 + 1;          /* bottom */
    strut[10] = dk.dock_x;                   /* bottom_start_x */
    strut[11] = dk.dock_x + dk.dock_w - 1;   /* bottom_end_x */
    Atom strut_a = XInternAtom(dk.dpy, "_NET_WM_STRUT_PARTIAL", False);
    XChangeProperty(dk.dpy, dk.win, strut_a, XA_CARDINAL, 32,
                    PropModeReplace, (unsigned char*)strut, 12);

    dk.gc = XCreateGC(dk.dpy, dk.win, 0, NULL);
    XMapRaised(dk.dpy, dk.win);
    XFlush(dk.dpy);

    /* init icon sizes */
    for (int i = 0; i < N_ICONS; i++) {
        icons[i].cur_size    = DOCK_ICON_SIZE;
        icons[i].target_size = DOCK_ICON_SIZE;
        icons[i].bounce_frame = 0;
    }
}

/* ── Calculate icon positions with zoom effect ────────────────────── */
static void dock_calc_geometry(int *xs, int *sizes) {
    /* compute zoomed sizes based on mouse distance */
    for (int i = 0; i < N_ICONS; i++) {
        int cx = (i * (DOCK_ICON_SIZE + DOCK_PADDING)) + DOCK_PADDING + DOCK_ICON_SIZE/2;
        double dist = (dk.mouse_x < 0) ? 999.0 : fabs((double)(dk.mouse_x - cx));
        double zoom_radius = DOCK_ICON_MAX * 2.0;
        double t = CLAMP(1.0 - dist / zoom_radius, 0.0, 1.0);
        icons[i].target_size = DOCK_ICON_SIZE + (DOCK_ICON_MAX - DOCK_ICON_SIZE) * t;
        /* lerp */
        icons[i].cur_size += (icons[i].target_size - icons[i].cur_size) * ZOOM_SPEED;
        sizes[i] = (int)icons[i].cur_size;
    }

    /* layout: centre all icons */
    int total = DOCK_PADDING;
    for (int i = 0; i < N_ICONS; i++) total += sizes[i] + DOCK_PADDING;
    int sx = (dk.dock_w - total) / 2 + DOCK_PADDING;
    for (int i = 0; i < N_ICONS; i++) {
        xs[i] = sx;
        sx += sizes[i] + DOCK_PADDING;
    }
}

/* ── Draw one icon placeholder ────────────────────────────────────── */
static void dock_draw_icon(int idx, int ix, int iy, int sz) {
    DockIcon *ic = &icons[idx];
    unsigned long col = ic->icon_color;

    /* bounce offset */
    int bounce_off = 0;
    if (ic->bounce_frame > 0) {
        double phase = (double)(ic->bounce_frame % BOUNCE_FRAMES) / BOUNCE_FRAMES;
        bounce_off = (int)(BOUNCE_AMP * fabs(sin(phase * M_PI)));
        iy -= bounce_off;
    }

    /* shadow */
    XSetForeground(dk.dpy, dk.gc, hex_color(dk.dpy, 0x00000060));
    XFillArc(dk.dpy, dk.win, dk.gc, ix+3, iy+sz-6+bounce_off, sz-6, 8, 0, 360*64);

    /* icon background (rounded rect) */
    XSetForeground(dk.dpy, dk.gc, col);
    draw_rounded_rect(dk.dpy, dk.win, dk.gc, ix, iy, sz, sz, sz/6);

    /* inner highlight (top) */
    XSetForeground(dk.dpy, dk.gc, hex_color(dk.dpy, 0xFFFFFF30));
    XFillArc(dk.dpy, dk.win, dk.gc, ix+2, iy+2, sz-4, sz/2, 0, 180*64);

    /* icon letter */
    if (dk.font) {
        char letter[4] = { ic->name[0], '\0' };
        XGlyphInfo ext;
        XftTextExtentsUtf8(dk.dpy, dk.font, (FcChar8*)letter, 1, &ext);
        XftDraw *draw = XftDrawCreate(dk.dpy, dk.win,
                                      DefaultVisual(dk.dpy, dk.screen),
                                      DefaultColormap(dk.dpy, dk.screen));
        XftColor white;
        alloc_xft_color(dk.dpy, dk.screen, COLOR_WHITE, &white);
        int tx = ix + (sz - ext.xOff) / 2;
        int ty = iy + (sz + dk.font->ascent) / 2;
        XftDrawStringUtf8(draw, &white, dk.font, tx, ty,
                          (FcChar8*)letter, 1);
        XftDrawDestroy(draw);
        XftColorFree(dk.dpy, DefaultVisual(dk.dpy, dk.screen),
                     DefaultColormap(dk.dpy, dk.screen), &white);
    }

    /* open indicator dot */
    if (ic->open) {
        int dot_x = ix + sz/2;
        int dot_y = iy + sz + 6 - bounce_off;
        XSetForeground(dk.dpy, dk.gc, hex_color(dk.dpy, COLOR_ACCENT_BLUE));
        XFillArc(dk.dpy, dk.win, dk.gc,
                 dot_x - DOT_RADIUS, dot_y - DOT_RADIUS,
                 DOT_RADIUS*2, DOT_RADIUS*2, 0, 360*64);
    }
}

/* ── Draw entire dock ─────────────────────────────────────────────── */
static void dock_draw(void) {
    int xs[MAX_ICONS], sizes[MAX_ICONS];
    dock_calc_geometry(xs, sizes);

    /* background */
    int W = dk.dock_w;
    int H = DOCK_HEIGHT + 4;

    /* semi-transparent dark bg */
    XSetForeground(dk.dpy, dk.gc, dk.col_bg);
    draw_rounded_rect(dk.dpy, dk.win, dk.gc, 0, 0, W, H, 12);

    /* border */
    XSetForeground(dk.dpy, dk.gc, dk.col_border);
    XDrawArc(dk.dpy, dk.win, dk.gc, 0, 0, 24, 24, 90*64, 90*64);
    XDrawArc(dk.dpy, dk.win, dk.gc, W-24, 0, 24, 24, 0, 90*64);
    XDrawLine(dk.dpy, dk.win, dk.gc, 12, 0, W-12, 0);
    XDrawLine(dk.dpy, dk.win, dk.gc, 0, 12, 0, H);
    XDrawLine(dk.dpy, dk.win, dk.gc, W-1, 12, W-1, H);

    /* icons */
    for (int i = 0; i < N_ICONS; i++) {
        if (dk.dragging && i == dk.drag_idx) continue; /* skip dragged icon */
        int iy = (DOCK_HEIGHT - sizes[i]) / 2 + 2;
        dock_draw_icon(i, xs[i], iy, sizes[i]);
    }

    /* draw dragged icon at cursor */
    if (dk.dragging && dk.drag_idx >= 0) {
        int sz = DOCK_ICON_MAX;
        int ix = dk.drag_cur_x - sz/2;
        int iy = (DOCK_HEIGHT - sz) / 2 + 2;
        /* clamp to dock */
        ix = CLAMP(ix, DOCK_PADDING, dk.dock_w - sz - DOCK_PADDING);
        dock_draw_icon(dk.drag_idx, ix, iy, sz);
    }

    XFlush(dk.dpy);
}

/* ── Draw context menu ────────────────────────────────────────────── */
static void dock_draw_ctx(void) {
    if (!dk.ctx_win) return;
    static const char *ctx_items[] = { "Opcions", "Sortir", NULL };
    int n = 0;
    for (const char **p = ctx_items; *p; p++) n++;
    int mh = n * CTX_ITEM_H + DOCK_PADDING;

    XSetForeground(dk.dpy, dk.gc, hex_color(dk.dpy, 0x24273A));
    XFillRectangle(dk.dpy, dk.ctx_win, dk.gc, 0, 0, CTX_WIDTH, mh);
    XSetForeground(dk.dpy, dk.gc, dk.col_border);
    XDrawRectangle(dk.dpy, dk.ctx_win, dk.gc, 0, 0, CTX_WIDTH-1, mh-1);

    XftDraw *draw = XftDrawCreate(dk.dpy, dk.ctx_win,
                                  DefaultVisual(dk.dpy, dk.screen),
                                  DefaultColormap(dk.dpy, dk.screen));
    for (int i = 0; i < n; i++) {
        int iy = DOCK_PADDING/2 + i * CTX_ITEM_H;
        if (i == dk.ctx_hover) {
            XSetForeground(dk.dpy, dk.gc, hex_color(dk.dpy, COLOR_ACCENT_BLUE));
            XFillRectangle(dk.dpy, dk.ctx_win, dk.gc, 2, iy, CTX_WIDTH-4, CTX_ITEM_H);
        }
        int ty = iy + (CTX_ITEM_H + dk.font->ascent) / 2;
        XftColor col;
        alloc_xft_color(dk.dpy, dk.screen,
                        i == dk.ctx_hover ? COLOR_WHITE : COLOR_TEXT_PRIMARY, &col);
        XftDrawStringUtf8(draw, &col, dk.font, DOCK_PADDING, ty,
                          (FcChar8*)ctx_items[i], strlen(ctx_items[i]));
        XftColorFree(dk.dpy, DefaultVisual(dk.dpy, dk.screen),
                     DefaultColormap(dk.dpy, dk.screen), &col);
    }
    XftDrawDestroy(draw);
    XFlush(dk.dpy);
}

/* ── Draw tooltip ─────────────────────────────────────────────────── */
static void dock_draw_tooltip(int idx) {
    if (!dk.tooltip_win || idx < 0 || idx >= N_ICONS) return;
    const char *name = icons[idx].name;
    int tw = 0;
    if (dk.font) {
        XGlyphInfo ext;
        XftTextExtentsUtf8(dk.dpy, dk.font, (FcChar8*)name, strlen(name), &ext);
        tw = ext.xOff + 16;
    } else { tw = 80; }

    XSetForeground(dk.dpy, dk.gc, hex_color(dk.dpy, 0x24273A));
    XFillRectangle(dk.dpy, dk.tooltip_win, dk.gc, 0, 0, tw, TOOLTIP_H);
    XSetForeground(dk.dpy, dk.gc, dk.col_border);
    XDrawRectangle(dk.dpy, dk.tooltip_win, dk.gc, 0, 0, tw-1, TOOLTIP_H-1);

    XftDraw *draw = XftDrawCreate(dk.dpy, dk.tooltip_win,
                                  DefaultVisual(dk.dpy, dk.screen),
                                  DefaultColormap(dk.dpy, dk.screen));
    int ty = (TOOLTIP_H + dk.font->ascent) / 2;
    XftDrawStringUtf8(draw, &dk.col_text, dk.font, 8, ty,
                      (FcChar8*)name, strlen(name));
    XftDrawDestroy(draw);
    XFlush(dk.dpy);
}

/* ── Open context menu ────────────────────────────────────────────── */
static void dock_open_ctx(int idx, int rx, int ry) {
    dock_close_ctx();
    dk.ctx_open  = 1;
    dk.ctx_idx   = idx;
    dk.ctx_hover = -1;

    static const char *ctx_items[] = { "Opcions", "Sortir", NULL };
    int n = 0; for (const char **p = ctx_items; *p; p++) n++;
    int mh = n * CTX_ITEM_H + DOCK_PADDING;

    XSetWindowAttributes wa;
    wa.background_pixel  = hex_color(dk.dpy, 0x24273A);
    wa.border_pixel      = dk.col_border;
    wa.override_redirect = True;
    wa.event_mask        = ExposureMask | ButtonPressMask | ButtonReleaseMask
                         | PointerMotionMask | LeaveWindowMask;

    dk.ctx_win = XCreateWindow(dk.dpy, dk.root,
                               rx, ry - mh - 4, CTX_WIDTH, mh, 1,
                               DefaultDepth(dk.dpy, dk.screen),
                               InputOutput,
                               DefaultVisual(dk.dpy, dk.screen),
                               CWBackPixel|CWBorderPixel|CWOverrideRedirect|CWEventMask, &wa);
    XMapRaised(dk.dpy, dk.ctx_win);
    dock_draw_ctx();
}

/* ── Close context menu ───────────────────────────────────────────── */
static void dock_close_ctx(void) {
    if (dk.ctx_win) { XDestroyWindow(dk.dpy, dk.ctx_win); dk.ctx_win = None; }
    dk.ctx_open  = 0;
    dk.ctx_hover = -1;
}

/* ── Launch application ───────────────────────────────────────────── */
static void dock_launch(int idx) {
    if (idx < 0 || idx >= N_ICONS) return;
    if (!icons[idx].exec) return;
    icons[idx].open = 1;
    dock_bounce(idx);
    spawn(icons[idx].exec);
}

/* ── Start bounce ─────────────────────────────────────────────────── */
static void dock_bounce(int idx) {
    icons[idx].bounce_frame = BOUNCE_FRAMES * BOUNCE_CYCLES;
}

/* ── Update bounce animations ─────────────────────────────────────── */
static void dock_update_bounce(void) {
    for (int i = 0; i < N_ICONS; i++)
        if (icons[i].bounce_frame > 0) icons[i].bounce_frame--;
}

/* ── Find icon at dock-local x ────────────────────────────────────── */
static int dock_icon_at(int lx) {
    int xs[MAX_ICONS], sizes[MAX_ICONS];
    dock_calc_geometry(xs, sizes);
    for (int i = 0; i < N_ICONS; i++)
        if (lx >= xs[i] && lx < xs[i] + sizes[i]) return i;
    return -1;
}

/* ── Handle button press ──────────────────────────────────────────── */
static void dock_handle_button(XButtonEvent *e) {
    if (e->window == dk.ctx_win) {
        static const char *ctx_items[] = { "Opcions", "Sortir", NULL };
        int n = 0; for (const char **p = ctx_items; *p; p++) n++;
        int y = e->y - DOCK_PADDING/2;
        if (y < 0) { dock_close_ctx(); return; }
        int item = y / CTX_ITEM_H;
        if (item >= n) { dock_close_ctx(); return; }
        if (item == 1 && dk.ctx_idx >= 0 && icons[dk.ctx_idx].exec) {
            /* Sortir: send SIGTERM to running process (best-effort) */
            char cmd[256];
            snprintf(cmd, sizeof(cmd), "pkill -f '%s'", icons[dk.ctx_idx].exec);
            spawn(cmd);
            icons[dk.ctx_idx].open = 0;
        }
        dock_close_ctx();
        return;
    }

    if (e->window != dk.win) { dock_close_ctx(); return; }

    int idx = dock_icon_at(e->x);

    if (e->button == 3) {
        /* right-click → context menu */
        if (idx >= 0) dock_open_ctx(idx, e->x_root, e->y_root);
        return;
    }

    if (e->button == 1 && idx >= 0) {
        /* start drag */
        dk.dragging   = 1;
        dk.drag_idx   = idx;
        dk.drag_cur_x = e->x;
        dk.drag_off_x = e->x;
        dock_close_ctx();
    }
}

/* ── Handle motion ────────────────────────────────────────────────── */
static void dock_handle_motion(XMotionEvent *e) {
    if (e->window == dk.ctx_win) {
        static const char *ctx_items[] = { "Opcions", "Sortir", NULL };
        int n = 0; for (const char **p = ctx_items; *p; p++) n++;
        int y = e->y - DOCK_PADDING/2;
        int item = (y >= 0) ? y / CTX_ITEM_H : -1;
        if (item >= n) item = -1;
        if (item != dk.ctx_hover) { dk.ctx_hover = item; dock_draw_ctx(); }
        return;
    }
    if (e->window != dk.win) return;

    dk.mouse_x = e->x;
    int idx = dock_icon_at(e->x);

    if (dk.dragging) {
        dk.drag_cur_x = e->x;
        /* reorder: find target slot */
        if (idx >= 0 && idx != dk.drag_idx) {
            /* swap */
            DockIcon tmp = icons[dk.drag_idx];
            icons[dk.drag_idx] = icons[idx];
            icons[idx] = tmp;
            dk.drag_idx = idx;
        }
    }

    /* tooltip */
    if (idx >= 0 && !dk.dragging) {
        if (!dk.tooltip_win || dk.tooltip_idx != idx) {
            if (dk.tooltip_win) { XDestroyWindow(dk.dpy, dk.tooltip_win); dk.tooltip_win = None; }
            int xs[MAX_ICONS], sizes[MAX_ICONS];
            dock_calc_geometry(xs, sizes);
            int tx = dk.dock_x + xs[idx] + sizes[idx]/2 - 40;
            int ty = dk.dock_y - TOOLTIP_H - 6;
            XSetWindowAttributes wa;
            wa.background_pixel  = hex_color(dk.dpy, 0x24273A);
            wa.border_pixel      = dk.col_border;
            wa.override_redirect = True;
            wa.event_mask        = ExposureMask;
            dk.tooltip_win = XCreateWindow(dk.dpy, dk.root, tx, ty, 120, TOOLTIP_H, 1,
                                           DefaultDepth(dk.dpy, dk.screen), InputOutput,
                                           DefaultVisual(dk.dpy, dk.screen),
                                           CWBackPixel|CWBorderPixel|CWOverrideRedirect|CWEventMask, &wa);
            XMapRaised(dk.dpy, dk.tooltip_win);
            dk.tooltip_idx = idx;
            dk.tooltip_show = 1;
            dock_draw_tooltip(idx);
        }
    } else {
        if (dk.tooltip_win) { XDestroyWindow(dk.dpy, dk.tooltip_win); dk.tooltip_win = None; }
        dk.tooltip_show = 0;
    }

    dk.hover_idx = idx;
    dock_draw();
}

/* ── Handle button release ────────────────────────────────────────── */
static void dock_handle_release(XButtonEvent *e) {
    if (e->window != dk.win) return;
    if (dk.dragging) {
        /* if not moved far, treat as click = launch */
        int dx = abs(e->x - dk.drag_off_x);
        if (dx < 6) dock_launch(dk.drag_idx);
        dk.dragging = 0;
        dk.drag_idx = -1;
    }
}

/* ── Handle leave ─────────────────────────────────────────────────── */
static void dock_handle_leave(void) {
    dk.mouse_x   = -1;
    dk.hover_idx = -1;
    if (dk.tooltip_win) { XDestroyWindow(dk.dpy, dk.tooltip_win); dk.tooltip_win = None; }
    dk.tooltip_show = 0;
}

/* ── Expose ───────────────────────────────────────────────────────── */
static void dock_handle_expose(void) { dock_draw(); }

/* ── Main loop ────────────────────────────────────────────────────── */
static void dock_run(void) {
    XEvent ev;
    struct timespec ts = { 0, 16 * 1000000L }; /* ~60fps */

    while (dk.running) {
        while (XPending(dk.dpy)) {
            XNextEvent(dk.dpy, &ev);
            switch (ev.type) {
                case Expose:
                    if (ev.xexpose.count == 0) dock_handle_expose();
                    break;
                case ButtonPress:
                    dock_handle_button(&ev.xbutton);
                    break;
                case ButtonRelease:
                    dock_handle_release(&ev.xbutton);
                    break;
                case MotionNotify:
                    while (XCheckTypedEvent(dk.dpy, MotionNotify, &ev));
                    dock_handle_motion(&ev.xmotion);
                    break;
                case LeaveNotify:
                    if (ev.xcrossing.window == dk.win) dock_handle_leave();
                    break;
                default: break;
            }
        }

        dock_update_bounce();
        dock_update_zoom();
        dock_draw();
        nanosleep(&ts, NULL);
    }
}

/* ── Update zoom lerp ─────────────────────────────────────────────── */
static void dock_update_zoom(void) {
    /* already done in calc_geometry, nothing extra needed */
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(void) {
    signal(SIGCHLD, SIG_IGN);
    dock_init();
    dock_run();
    return 0;
}
