/*
 * topbar.c — Alpine Desktop Environment: Top Bar
 * macOS-style top panel: logo+menu, app title, clock, battery, volume
 * Compile: gcc -O2 -o topbar topbar.c -lX11 -lXft -lfontconfig -lasound -lm
 */
#include "../include/common.h"
#include <alsa/asoundlib.h>
#include <alsa/mixer.h>

/* ── Constants ───────────────────────────────────────────────────── */
#define MENU_ITEM_H      24
#define MENU_WIDTH       180
#define MENU_PADDING     8
#define POLL_INTERVAL_MS 1000

/* ── Menu item ───────────────────────────────────────────────────── */
typedef struct {
    const char *label;
    const char *command;
} MenuItem;

static MenuItem apple_menu[] = {
    { "Sobre Alpine DE",   "notify 'Alpine Desktop Environment' 'Entorn d\\'escriptori per Alpine Linux aarch64'" },
    { "Configuració",      "xterm -e vi ~/.config/de/config" },
    { "Bloquejar sessió",  "xdg-screensaver lock" },
    { "Tancar sessió",     "pkill -u $USER" },
    { "Apagar",            "poweroff" },
    { NULL, NULL }
};

static MenuItem file_menu[] = {
    { "Nou",       "true" },
    { "Obrir...",  "true" },
    { "Desar",     "true" },
    { "Desar com...","true" },
    { "Tancar",    "true" },
    { NULL, NULL }
};

static MenuItem edit_menu[] = {
    { "Desfés",     "true" },
    { "Refés",      "true" },
    { "Retallar",   "true" },
    { "Copiar",     "true" },
    { "Enganxar",   "true" },
    { "Seleccionar tot","true" },
    { NULL, NULL }
};

static MenuItem view_menu[] = {
    { "Zoom +",   "true" },
    { "Zoom -",   "true" },
    { "Pantalla completa","true" },
    { NULL, NULL }
};

typedef struct {
    const char *name;
    MenuItem   *items;
} MenuGroup;

static MenuGroup global_menus[] = {
    { "Fitxer",    file_menu  },
    { "Edita",     edit_menu  },
    { "Visualitza",view_menu  },
};
#define N_GLOBAL_MENUS ((int)ARRLEN(global_menus))

/* ── Topbar state ────────────────────────────────────────────────── */
typedef struct {
    Display   *dpy;
    int        screen;
    Window     root;
    Window     win;
    int        sw, sh;
    GC         gc;
    XftFont   *font_normal;
    XftFont   *font_bold;
    XftFont   *font_small;
    XftDraw   *draw;
    XftColor   col_text, col_text_dim, col_bg_sel;
    /* colors */
    unsigned long col_bg, col_border, col_hover, col_active;
    /* state */
    char       app_title[256];
    char       clock_str[64];
    int        battery_pct;
    int        battery_charging;
    int        volume_pct;
    int        volume_muted;
    /* menus */
    int        apple_open;
    int        global_open;   /* index into global_menus, or -1 */
    Window     menu_win;
    int        menu_hover;
    MenuItem  *menu_items;    /* currently open menu items */
    /* geometry cache */
    int        apple_x, apple_w;
    int        gmenu_x[3];
    int        gmenu_w[3];
    int        clock_x;
    int        bat_x;
    int        vol_x;
    /* atoms */
    Atom       focus_prop;
    /* running */
    int        running;
} TopBar;

static TopBar tb;

/* ── Forward declarations ────────────────────────────────────────── */
static void tb_init(void);
static void tb_run(void);
static void tb_draw(void);
static void tb_draw_menu(void);
static void tb_update_clock(void);
static void tb_update_battery(void);
static void tb_update_volume(void);
static void tb_update_title(void);
static void tb_open_apple_menu(void);
static void tb_open_global_menu(int idx);
static void tb_close_menu(void);
static void tb_menu_click(int item_idx);
static void tb_handle_button(XButtonEvent *e);
static void tb_handle_expose(void);
static void tb_handle_enter(XCrossingEvent *e);
static void tb_handle_leave(XCrossingEvent *e);
static void tb_handle_property(XPropertyEvent *e);

/* ── Helpers ─────────────────────────────────────────────────────── */
static int xft_text_width(XftFont *f, const char *s) {
    if (!s || !f) return 0;
    XGlyphInfo ext;
    XftTextExtentsUtf8(tb.dpy, f, (FcChar8*)s, strlen(s), &ext);
    return ext.xOff;
}

static void fill_rect(Window w, unsigned long col, int x, int y, int wd, int h) {
    XSetForeground(tb.dpy, tb.gc, col);
    XFillRectangle(tb.dpy, w, tb.gc, x, y, wd, h);
}

static void draw_text(Window w, XftDraw *drw, XftFont *f, XftColor *c,
                      int x, int y_baseline, const char *s) {
    if (!s || !drw) return;
    XftDrawStringUtf8(drw, c, f, x, y_baseline, (FcChar8*)s, strlen(s));
}

/* ── Init ─────────────────────────────────────────────────────────── */
static void tb_init(void) {
    tb.dpy    = XOpenDisplay(NULL);
    if (!tb.dpy) { fprintf(stderr, "topbar: cannot open display\n"); exit(1); }
    tb.screen = DefaultScreen(tb.dpy);
    tb.root   = RootWindow(tb.dpy, tb.screen);
    tb.sw     = DisplayWidth(tb.dpy, tb.screen);
    tb.sh     = DisplayHeight(tb.dpy, tb.screen);
    tb.running = 1;
    tb.apple_open  = 0;
    tb.global_open = -1;
    tb.menu_win    = None;
    tb.menu_hover  = -1;
    strcpy(tb.app_title, "Finder");

    /* colors */
    tb.col_bg     = hex_color(tb.dpy, COLOR_TOPBAR_BG);
    tb.col_border = hex_color(tb.dpy, COLOR_BORDER);
    tb.col_hover  = hex_color(tb.dpy, COLOR_HOVER);
    tb.col_active = hex_color(tb.dpy, COLOR_SELECTION);

    /* fonts */
    tb.font_normal = load_font(tb.dpy, tb.screen, FONT_UI);
    tb.font_bold   = load_font(tb.dpy, tb.screen, FONT_UI_BOLD);
    tb.font_small  = load_font(tb.dpy, tb.screen, FONT_UI_SMALL);

    alloc_xft_color(tb.dpy, tb.screen, COLOR_TEXT_PRIMARY,   &tb.col_text);
    alloc_xft_color(tb.dpy, tb.screen, COLOR_TEXT_SECONDARY, &tb.col_text_dim);
    alloc_xft_color(tb.dpy, tb.screen, COLOR_SELECTION,      &tb.col_bg_sel);

    /* create panel window */
    XSetWindowAttributes wa;
    wa.background_pixel  = tb.col_bg;
    wa.border_pixel      = tb.col_border;
    wa.override_redirect = True;
    wa.event_mask        = ExposureMask | ButtonPressMask | ButtonReleaseMask
                         | EnterWindowMask | LeaveWindowMask
                         | PointerMotionMask | PropertyChangeMask;

    tb.win = XCreateWindow(tb.dpy, tb.root,
                           0, 0, tb.sw, TOPBAR_HEIGHT, 0,
                           DefaultDepth(tb.dpy, tb.screen),
                           InputOutput,
                           DefaultVisual(tb.dpy, tb.screen),
                           CWBackPixel|CWBorderPixel|CWOverrideRedirect|CWEventMask, &wa);

    /* EWMH dock hints */
    Atom wtype = XInternAtom(tb.dpy, "_NET_WM_WINDOW_TYPE_DOCK", False);
    Atom wtype_a = XInternAtom(tb.dpy, "_NET_WM_WINDOW_TYPE", False);
    XChangeProperty(tb.dpy, tb.win, wtype_a, XA_ATOM, 32,
                    PropModeReplace, (unsigned char*)&wtype, 1);

    long strut[12] = {0};
    strut[2] = TOPBAR_HEIGHT;   /* top strut */
    strut[8] = 0;               /* top_start_x */
    strut[9] = tb.sw - 1;       /* top_end_x */
    Atom strut_a = XInternAtom(tb.dpy, "_NET_WM_STRUT_PARTIAL", False);
    XChangeProperty(tb.dpy, tb.win, strut_a, XA_CARDINAL, 32,
                    PropModeReplace, (unsigned char*)strut, 12);

    tb.gc = XCreateGC(tb.dpy, tb.win, 0, NULL);
    tb.draw = XftDrawCreate(tb.dpy, tb.win,
                            DefaultVisual(tb.dpy, tb.screen),
                            DefaultColormap(tb.dpy, tb.screen));

    /* watch root for focus IPC */
    XSelectInput(tb.dpy, tb.root, PropertyChangeMask);
    tb.focus_prop = XInternAtom(tb.dpy, IPC_PROP_FOCUS, False);

    XMapRaised(tb.dpy, tb.win);
    XFlush(tb.dpy);

    /* initial state */
    tb_update_clock();
    tb_update_battery();
    tb_update_volume();
}

/* ── Draw topbar ──────────────────────────────────────────────────── */
static void tb_draw(void) {
    int W = tb.sw;
    int H = TOPBAR_HEIGHT;
    int cy = (H + tb.font_normal->ascent) / 2; /* baseline */

    /* background */
    fill_rect(tb.win, tb.col_bg, 0, 0, W, H);

    /* ── Left zone: Apple logo + global menus ─────────────────────── */
    int x = 10;

    /* Apple  logo */
    tb.apple_x = x;
    const char *apple = "";
    int aw = xft_text_width(tb.font_bold, apple) + 12;
    tb.apple_w = aw;
    if (tb.apple_open)
        fill_rect(tb.win, tb.col_active, x-4, 0, aw+4, H);
    draw_text(tb.win, tb.draw, tb.font_bold, &tb.col_text, x, cy, apple);
    x += aw + 8;

    /* separator */
    XSetForeground(tb.dpy, tb.gc, tb.col_border);
    XDrawLine(tb.dpy, tb.win, tb.gc, x-4, 4, x-4, H-4);

    /* global menus */
    for (int i = 0; i < N_GLOBAL_MENUS; i++) {
        tb.gmenu_x[i] = x;
        int tw = xft_text_width(tb.font_normal, global_menus[i].name) + 12;
        tb.gmenu_w[i] = tw;
        if (tb.global_open == i)
            fill_rect(tb.win, tb.col_active, x-4, 0, tw+4, H);
        draw_text(tb.win, tb.draw, tb.font_normal, &tb.col_text, x, cy, global_menus[i].name);
        x += tw + 4;
    }

    /* ── Centre: app title ────────────────────────────────────────── */
    int tw = xft_text_width(tb.font_bold, tb.app_title);
    int tx = (W - tw) / 2;
    draw_text(tb.win, tb.draw, tb.font_bold, &tb.col_text, tx, cy, tb.app_title);

    /* ── Right zone: vol, bat, clock ──────────────────────────────── */
    x = W - 10;

    /* Clock */
    int cw = xft_text_width(tb.font_normal, tb.clock_str);
    x -= cw;
    tb.clock_x = x;
    draw_text(tb.win, tb.draw, tb.font_normal, &tb.col_text, x, cy, tb.clock_str);
    x -= 12;

    /* separator */
    XSetForeground(tb.dpy, tb.gc, tb.col_border);
    XDrawLine(tb.dpy, tb.win, tb.gc, x+4, 4, x+4, H-4);

    /* Battery */
    char bat_str[32];
    const char *bat_icon = tb.battery_charging ? "⚡" : (tb.battery_pct > 80 ? "🔋" :
                           tb.battery_pct > 40 ? "🔋" : tb.battery_pct > 20 ? "🪫" : "🪫");
    snprintf(bat_str, sizeof(bat_str), "%s %d%%", bat_icon, tb.battery_pct);
    int bw = xft_text_width(tb.font_normal, bat_str);
    x -= bw + 8;
    tb.bat_x = x;
    XftColor *bat_col = tb.battery_pct < 20 ? &tb.col_text_dim : &tb.col_text;
    draw_text(tb.win, tb.draw, tb.font_normal, bat_col, x, cy, bat_str);
    x -= 12;

    /* separator */
    XSetForeground(tb.dpy, tb.gc, tb.col_border);
    XDrawLine(tb.dpy, tb.win, tb.gc, x+4, 4, x+4, H-4);

    /* Volume */
    char vol_str[32];
    const char *vol_icon = tb.volume_muted ? "🔇" :
                           tb.volume_pct > 60 ? "🔊" :
                           tb.volume_pct > 20 ? "🔉" : "🔈";
    snprintf(vol_str, sizeof(vol_str), "%s %d%%", vol_icon, tb.volume_pct);
    int vw = xft_text_width(tb.font_normal, vol_str);
    x -= vw + 8;
    tb.vol_x = x;
    draw_text(tb.win, tb.draw, tb.font_normal, &tb.col_text, x, cy, vol_str);

    /* bottom border */
    XSetForeground(tb.dpy, tb.gc, tb.col_border);
    XDrawLine(tb.dpy, tb.win, tb.gc, 0, H-1, W, H-1);

    XFlush(tb.dpy);
}

/* ── Draw dropdown menu ───────────────────────────────────────────── */
static void tb_draw_menu(void) {
    if (!tb.menu_win || !tb.menu_items) return;

    int n = 0;
    for (MenuItem *m = tb.menu_items; m->label; m++) n++;

    int mh = n * MENU_ITEM_H + MENU_PADDING * 2;
    unsigned long bg  = hex_color(tb.dpy, 0x24273A);
    unsigned long brd = hex_color(tb.dpy, COLOR_BORDER);

    XSetForeground(tb.dpy, tb.gc, bg);
    XFillRectangle(tb.dpy, tb.menu_win, tb.gc, 0, 0, MENU_WIDTH, mh);
    XSetForeground(tb.dpy, tb.gc, brd);
    XDrawRectangle(tb.dpy, tb.menu_win, tb.gc, 0, 0, MENU_WIDTH-1, mh-1);

    XftDraw *draw = XftDrawCreate(tb.dpy, tb.menu_win,
                                  DefaultVisual(tb.dpy, tb.screen),
                                  DefaultColormap(tb.dpy, tb.screen));
    for (int i = 0; i < n; i++) {
        int iy = MENU_PADDING + i * MENU_ITEM_H;
        if (i == tb.menu_hover) {
            XSetForeground(tb.dpy, tb.gc, hex_color(tb.dpy, COLOR_ACCENT_BLUE));
            XFillRectangle(tb.dpy, tb.menu_win, tb.gc,
                           2, iy, MENU_WIDTH-4, MENU_ITEM_H);
        }
        int ty = iy + (MENU_ITEM_H + tb.font_normal->ascent) / 2;
        XftColor *col = (i == tb.menu_hover) ? &tb.col_bg_sel : &tb.col_text;
        /* use bg_sel as white for highlight */
        if (i == tb.menu_hover) {
            alloc_xft_color(tb.dpy, tb.screen, COLOR_WHITE, col);
        }
        draw_text(tb.menu_win, draw, tb.font_normal, col,
                  MENU_PADDING, ty, tb.menu_items[i].label);
    }
    XftDrawDestroy(draw);
    XFlush(tb.dpy);
}

/* ── Open apple menu ──────────────────────────────────────────────── */
static void tb_open_apple_menu(void) {
    tb_close_menu();
    tb.apple_open = 1;
    tb.menu_items = apple_menu;
    tb.menu_hover = -1;

    int n = 0;
    for (MenuItem *m = apple_menu; m->label; m++) n++;
    int mh = n * MENU_ITEM_H + MENU_PADDING * 2;

    XSetWindowAttributes wa;
    wa.background_pixel  = hex_color(tb.dpy, 0x24273A);
    wa.border_pixel      = hex_color(tb.dpy, COLOR_BORDER);
    wa.override_redirect = True;
    wa.event_mask        = ExposureMask | ButtonPressMask | ButtonReleaseMask
                         | PointerMotionMask | LeaveWindowMask;

    tb.menu_win = XCreateWindow(tb.dpy, tb.root,
                                tb.apple_x - 4, TOPBAR_HEIGHT,
                                MENU_WIDTH, mh, 1,
                                DefaultDepth(tb.dpy, tb.screen),
                                InputOutput,
                                DefaultVisual(tb.dpy, tb.screen),
                                CWBackPixel|CWBorderPixel|CWOverrideRedirect|CWEventMask, &wa);
    XMapRaised(tb.dpy, tb.menu_win);
    tb_draw();
    tb_draw_menu();
}

/* ── Open global menu ─────────────────────────────────────────────── */
static void tb_open_global_menu(int idx) {
    tb_close_menu();
    tb.global_open = idx;
    tb.menu_items  = global_menus[idx].items;
    tb.menu_hover  = -1;

    int n = 0;
    for (MenuItem *m = tb.menu_items; m->label; m++) n++;
    int mh = n * MENU_ITEM_H + MENU_PADDING * 2;

    XSetWindowAttributes wa;
    wa.background_pixel  = hex_color(tb.dpy, 0x24273A);
    wa.border_pixel      = hex_color(tb.dpy, COLOR_BORDER);
    wa.override_redirect = True;
    wa.event_mask        = ExposureMask | ButtonPressMask | ButtonReleaseMask
                         | PointerMotionMask | LeaveWindowMask;

    tb.menu_win = XCreateWindow(tb.dpy, tb.root,
                                tb.gmenu_x[idx] - 4, TOPBAR_HEIGHT,
                                MENU_WIDTH, mh, 1,
                                DefaultDepth(tb.dpy, tb.screen),
                                InputOutput,
                                DefaultVisual(tb.dpy, tb.screen),
                                CWBackPixel|CWBorderPixel|CWOverrideRedirect|CWEventMask, &wa);
    XMapRaised(tb.dpy, tb.menu_win);
    tb_draw();
    tb_draw_menu();
}

/* ── Close any open menu ──────────────────────────────────────────── */
static void tb_close_menu(void) {
    if (tb.menu_win) {
        XDestroyWindow(tb.dpy, tb.menu_win);
        tb.menu_win = None;
    }
    tb.apple_open  = 0;
    tb.global_open = -1;
    tb.menu_items  = NULL;
    tb.menu_hover  = -1;
    tb_draw();
}

/* ── Execute menu item ────────────────────────────────────────────── */
static void tb_menu_click(int item_idx) {
    if (!tb.menu_items) return;
    int n = 0;
    for (MenuItem *m = tb.menu_items; m->label; m++) n++;
    if (item_idx < 0 || item_idx >= n) return;
    const char *cmd = tb.menu_items[item_idx].command;
    if (cmd) spawn(cmd);
    tb_close_menu();
}

/* ── Update clock string ──────────────────────────────────────────── */
static void tb_update_clock(void) {
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    static const char *dies[] = { "diu.", "dil.", "dim.", "dmc.", "dij.", "div.", "dis." };
    static const char *mesos[] = { "gen.", "feb.", "mar.", "abr.", "mai.", "jun.",
                                    "jul.", "ago.", "set.", "oct.", "nov.", "des." };
    snprintf(tb.clock_str, sizeof(tb.clock_str),
             "%s %d %s %02d:%02d",
             dies[tm->tm_wday], tm->tm_mday,
             mesos[tm->tm_mon], tm->tm_hour, tm->tm_min);
}

/* ── Update battery ───────────────────────────────────────────────── */
static void tb_update_battery(void) {
    FILE *f;
    char path[256], buf[32];
    /* try BAT0 then BAT1 */
    for (int i = 0; i < 2; i++) {
        snprintf(path, sizeof(path), "/sys/class/power_supply/BAT%d/capacity", i);
        f = fopen(path, "r");
        if (f) {
            if (fgets(buf, sizeof(buf), f)) tb.battery_pct = atoi(buf);
            fclose(f);
            snprintf(path, sizeof(path), "/sys/class/power_supply/BAT%d/status", i);
            f = fopen(path, "r");
            if (f) {
                if (fgets(buf, sizeof(buf), f))
                    tb.battery_charging = (strncmp(buf, "Charging", 8) == 0);
                fclose(f);
            }
            return;
        }
    }
    /* no battery (desktop) */
    tb.battery_pct = 100;
    tb.battery_charging = 0;
}

/* ── Update volume ────────────────────────────────────────────────── */
static void tb_update_volume(void) {
    snd_mixer_t *handle = NULL;
    if (snd_mixer_open(&handle, 0) < 0) { tb.volume_pct = 75; return; }
    if (snd_mixer_attach(handle, "default") < 0) { snd_mixer_close(handle); tb.volume_pct = 75; return; }
    snd_mixer_selem_register(handle, NULL, NULL);
    snd_mixer_load(handle);

    snd_mixer_selem_id_t *sid;
    snd_mixer_selem_id_alloca(&sid);
    snd_mixer_selem_id_set_index(sid, 0);
    snd_mixer_selem_id_set_name(sid, "Master");

    snd_mixer_elem_t *elem = snd_mixer_find_selem(handle, sid);
    if (elem) {
        long vol, vol_min, vol_max;
        snd_mixer_selem_get_playback_volume_range(elem, &vol_min, &vol_max);
        snd_mixer_selem_get_playback_volume(elem, SND_MIXER_SCHN_MONO, &vol);
        tb.volume_pct = (int)((vol - vol_min) * 100 / (vol_max - vol_min));
        int sw = 0;
        snd_mixer_selem_get_playback_switch(elem, SND_MIXER_SCHN_MONO, &sw);
        tb.volume_muted = !sw;
    } else {
        tb.volume_pct = 75;
        tb.volume_muted = 0;
    }
    snd_mixer_close(handle);
}

/* ── Update title from IPC ────────────────────────────────────────── */
static void tb_update_title(void) {
    char *val = ipc_get_prop(tb.dpy, IPC_PROP_FOCUS);
    if (val) {
        strncpy(tb.app_title, val, sizeof(tb.app_title)-1);
        tb.app_title[sizeof(tb.app_title)-1] = '\0';
        XFree(val);
    }
}

/* ── Hit test right-side widgets ──────────────────────────────────── */
static void tb_handle_button(XButtonEvent *e) {
    if (e->window == tb.menu_win) {
        /* click inside menu */
        int y = e->y - MENU_PADDING;
        if (y >= 0) tb_menu_click(y / MENU_ITEM_H);
        return;
    }

    if (e->window != tb.win) { tb_close_menu(); return; }

    int x = e->x;

    /* Apple logo */
    if (x >= tb.apple_x - 4 && x < tb.apple_x + tb.apple_w) {
        if (tb.apple_open) tb_close_menu();
        else tb_open_apple_menu();
        return;
    }

    /* Global menus */
    for (int i = 0; i < N_GLOBAL_MENUS; i++) {
        if (x >= tb.gmenu_x[i] - 4 && x < tb.gmenu_x[i] + tb.gmenu_w[i]) {
            if (tb.global_open == i) tb_close_menu();
            else tb_open_global_menu(i);
            return;
        }
    }

    /* Clock → open simple date popup */
    if (x >= tb.clock_x - 4) {
        /* simple date notification */
        char cmd[128];
        time_t t = time(NULL);
        struct tm *tm = localtime(&t);
        snprintf(cmd, sizeof(cmd),
                 "notify 'Calendari' '%04d-%02d-%02d'",
                 tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday);
        spawn(cmd);
        return;
    }

    if (tb.apple_open || tb.global_open >= 0) tb_close_menu();
}

/* ── Motion in menu window → highlight ───────────────────────────── */
static void tb_handle_motion(XMotionEvent *e) {
    if (e->window != tb.menu_win || !tb.menu_items) return;
    int y = e->y - MENU_PADDING;
    int idx = (y >= 0) ? y / MENU_ITEM_H : -1;
    int n = 0;
    for (MenuItem *m = tb.menu_items; m->label; m++) n++;
    if (idx >= n) idx = -1;
    if (idx != tb.menu_hover) { tb.menu_hover = idx; tb_draw_menu(); }
}

/* ── Expose ───────────────────────────────────────────────────────── */
static void tb_handle_expose(void) { tb_draw(); }

/* ── Main loop ────────────────────────────────────────────────────── */
static void tb_run(void) {
    XEvent ev;
    struct timespec ts = { 0, POLL_INTERVAL_MS * 1000000L };

    while (tb.running) {
        while (XPending(tb.dpy)) {
            XNextEvent(tb.dpy, &ev);
            switch (ev.type) {
                case Expose:
                    if (ev.xexpose.count == 0) tb_handle_expose();
                    break;
                case ButtonPress:
                    tb_handle_button(&ev.xbutton);
                    break;
                case MotionNotify:
                    tb_handle_motion(&ev.xmotion);
                    break;
                case LeaveNotify:
                    if (ev.xcrossing.window == tb.menu_win) {
                        /* only close if leaving to outside, not into topbar */
                        if (ev.xcrossing.detail != NotifyInferior) {
                            /* keep open — user may move to topbar */
                        }
                    }
                    break;
                case PropertyNotify:
                    if (ev.xproperty.atom == tb.focus_prop)
                        tb_update_title();
                    tb_draw();
                    break;
                default: break;
            }
        }

        /* periodic updates */
        static int tick = 0;
        tick++;
        tb_update_clock();
        if (tick % 30 == 0) { tb_update_battery(); tb_update_volume(); }
        tb_draw();
        nanosleep(&ts, NULL);
    }
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(void) {
    signal(SIGCHLD, SIG_IGN);
    tb_init();
    tb_run();
    return 0;
}
