/*
 * wallpaper.c — Alpine Desktop Environment: Wallpaper setter
 * Sets root window background from PNG/JPEG file
 * Falls back to solid gradient if no file given
 * Compile: gcc -O2 -o wallpaper wallpaper.c -lX11 -lXft -lpng -lm
 * Usage: wallpaper [image.png] [scaled|tiled|centered]
 */
#include "../include/common.h"
#include <png.h>

/* ── Simple PNG loader ────────────────────────────────────────────── */
typedef struct {
    unsigned char *data;    /* RGBA rows */
    int width, height;
} Image;

static Image *load_png(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;

    unsigned char sig[8];
    if (fread(sig, 1, 8, f) != 8 || png_sig_cmp(sig, 0, 8)) { fclose(f); return NULL; }

    png_structp png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (!png) { fclose(f); return NULL; }
    png_infop info = png_create_info_struct(png);
    if (!info) { png_destroy_read_struct(&png, NULL, NULL); fclose(f); return NULL; }

    if (setjmp(png_jmpbuf(png))) {
        png_destroy_read_struct(&png, &info, NULL);
        fclose(f);
        return NULL;
    }

    png_init_io(png, f);
    png_set_sig_bytes(png, 8);
    png_read_info(png, info);

    int width  = png_get_image_width(png, info);
    int height = png_get_image_height(png, info);
    png_byte color_type = png_get_color_type(png, info);
    png_byte bit_depth  = png_get_bit_depth(png, info);

    if (bit_depth == 16)             png_set_strip_16(png);
    if (color_type == PNG_COLOR_TYPE_PALETTE) png_set_palette_to_rgb(png);
    if (color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8) png_set_expand_gray_1_2_4_to_8(png);
    if (png_get_valid(png, info, PNG_INFO_tRNS)) png_set_tRNS_to_alpha(png);
    if (color_type == PNG_COLOR_TYPE_RGB  ||
        color_type == PNG_COLOR_TYPE_GRAY ||
        color_type == PNG_COLOR_TYPE_PALETTE) png_set_filler(png, 0xFF, PNG_FILLER_AFTER);
    if (color_type == PNG_COLOR_TYPE_GRAY ||
        color_type == PNG_COLOR_TYPE_GRAY_ALPHA) png_set_gray_to_rgb(png);
    png_read_update_info(png, info);

    Image *img = calloc(1, sizeof(Image));
    img->width  = width;
    img->height = height;
    img->data   = malloc((size_t)(width * height * 4));

    png_bytep *rows = malloc(sizeof(png_bytep) * height);
    for (int y = 0; y < height; y++)
        rows[y] = img->data + y * width * 4;
    png_read_image(png, rows);
    free(rows);

    png_destroy_read_struct(&png, &info, NULL);
    fclose(f);
    return img;
}

static void free_image(Image *img) {
    if (img) { free(img->data); free(img); }
}

/* ── Scale image to fit screen ────────────────────────────────────── */
static Image *scale_image(const Image *src, int dw, int dh) {
    Image *dst = calloc(1, sizeof(Image));
    dst->width  = dw;
    dst->height = dh;
    dst->data   = malloc((size_t)(dw * dh * 4));

    double sx = (double)src->width  / dw;
    double sy = (double)src->height / dh;

    for (int dy = 0; dy < dh; dy++) {
        int sy_i = (int)(dy * sy);
        if (sy_i >= src->height) sy_i = src->height - 1;
        for (int dx = 0; dx < dw; dx++) {
            int sx_i = (int)(dx * sx);
            if (sx_i >= src->width) sx_i = src->width - 1;
            unsigned char *sp = src->data + (sy_i * src->width + sx_i) * 4;
            unsigned char *dp = dst->data + (dy * dw + dx) * 4;
            dp[0] = sp[0]; dp[1] = sp[1]; dp[2] = sp[2]; dp[3] = sp[3];
        }
    }
    return dst;
}

/* ── Apply image to root window ───────────────────────────────────── */
static void apply_wallpaper(Display *dpy, Image *img, int screen) {
    Window root = RootWindow(dpy, screen);
    int sw = DisplayWidth(dpy, screen);
    int sh = DisplayHeight(dpy, screen);
    int depth = DefaultDepth(dpy, screen);
    Visual *vis = DefaultVisual(dpy, screen);

    /* create pixmap */
    Pixmap pix = XCreatePixmap(dpy, root, sw, sh, depth);
    GC gc = XCreateGC(dpy, pix, 0, NULL);

    /* draw image row by row */
    XImage *xi = XCreateImage(dpy, vis, depth, ZPixmap, 0, NULL, sw, sh, 32, 0);
    xi->data = calloc(sh, xi->bytes_per_line);

    int iw = img->width;
    int ih = img->height;

    for (int y = 0; y < sh; y++) {
        for (int x = 0; x < sw; x++) {
            int px = CLAMP(x, 0, iw-1);
            int py = CLAMP(y, 0, ih-1);
            unsigned char *p = img->data + (py * iw + px) * 4;
            unsigned long pixel = ((unsigned long)p[0] << 16) |
                                  ((unsigned long)p[1] <<  8) |
                                   (unsigned long)p[2];
            XPutPixel(xi, x, y, pixel);
        }
    }

    XPutImage(dpy, pix, gc, xi, 0, 0, 0, 0, sw, sh);
    XDestroyImage(xi);
    XFreeGC(dpy, gc);

    /* set as root background */
    XSetWindowBackgroundPixmap(dpy, root, pix);
    XClearWindow(dpy, root);

    /* set _XROOTPMAP_ID for compositing */
    Atom xrootpmap = XInternAtom(dpy, "_XROOTPMAP_ID", False);
    XChangeProperty(dpy, root, xrootpmap, XA_PIXMAP, 32, PropModeReplace,
                    (unsigned char*)&pix, 1);
    Atom esetroot = XInternAtom(dpy, "ESETROOT_PMAP_ID", False);
    XChangeProperty(dpy, root, esetroot, XA_PIXMAP, 32, PropModeReplace,
                    (unsigned char*)&pix, 1);

    XFlush(dpy);
    /* Note: don't free pix — it must persist as root background */
}

/* ── Draw gradient fallback ───────────────────────────────────────── */
static void draw_gradient(Display *dpy, int screen) {
    Window root = RootWindow(dpy, screen);
    int sw = DisplayWidth(dpy, screen);
    int sh = DisplayHeight(dpy, screen);
    int depth = DefaultDepth(dpy, screen);

    Pixmap pix = XCreatePixmap(dpy, root, sw, sh, depth);
    GC gc = XCreateGC(dpy, pix, 0, NULL);

    /* gradient from dark blue-purple to dark */
    for (int y = 0; y < sh; y++) {
        double t  = (double)y / sh;
        int r = (int)(0x18 + (0x1E - 0x18) * t);
        int g = (int)(0x18 + (0x1E - 0x18) * t);
        int b = (int)(0x30 + (0x2E - 0x30) * t);
        unsigned long col = hex_color(dpy, (r<<16)|(g<<8)|b);
        XSetForeground(dpy, gc, col);
        XDrawLine(dpy, pix, gc, 0, y, sw, y);
    }

    /* subtle grid pattern */
    XSetForeground(dpy, gc, hex_color(dpy, 0x2A2D3E));
    for (int x = 0; x < sw; x += 40)
        XDrawLine(dpy, pix, gc, x, 0, x, sh);
    for (int y = 0; y < sh; y += 40)
        XDrawLine(dpy, pix, gc, 0, y, sw, y);

    XSetWindowBackgroundPixmap(dpy, root, pix);
    XClearWindow(dpy, root);
    XFreeGC(dpy, gc);
    XFlush(dpy);
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(int argc, char *argv[]) {
    Display *dpy = XOpenDisplay(NULL);
    if (!dpy) { fprintf(stderr, "wallpaper: cannot open display\n"); return 1; }

    int screen = DefaultScreen(dpy);
    int sw     = DisplayWidth(dpy, screen);
    int sh     = DisplayHeight(dpy, screen);

    if (argc < 2) {
        fprintf(stderr, "wallpaper: no image given, using gradient\n");
        draw_gradient(dpy, screen);
        XCloseDisplay(dpy);
        return 0;
    }

    const char *path = argv[1];
    const char *mode = (argc >= 3) ? argv[2] : "scaled";

    Image *img = load_png(path);
    if (!img) {
        fprintf(stderr, "wallpaper: cannot load '%s', using gradient\n", path);
        draw_gradient(dpy, screen);
        XCloseDisplay(dpy);
        return 0;
    }

    Image *final = NULL;

    if (strcmp(mode, "tiled") == 0) {
        /* tile: keep original size, apply_wallpaper handles wrapping via CLAMP... */
        /* for tiled, build a full-screen image */
        final = calloc(1, sizeof(Image));
        final->width  = sw;
        final->height = sh;
        final->data   = malloc((size_t)(sw * sh * 4));
        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                int px = x % img->width;
                int py = y % img->height;
                unsigned char *sp = img->data + (py * img->width + px) * 4;
                unsigned char *dp = final->data + (y * sw + x) * 4;
                dp[0]=sp[0]; dp[1]=sp[1]; dp[2]=sp[2]; dp[3]=sp[3];
            }
        }
    } else if (strcmp(mode, "centered") == 0) {
        /* center on solid bg */
        final = calloc(1, sizeof(Image));
        final->width  = sw;
        final->height = sh;
        final->data   = calloc(sw * sh * 4, 1);
        /* fill bg */
        unsigned char bg[4] = { 0x1E, 0x1E, 0x2E, 0xFF };
        for (int i = 0; i < sw*sh; i++)
            memcpy(final->data + i*4, bg, 4);
        /* blit centered */
        int ox = (sw - img->width)  / 2;
        int oy = (sh - img->height) / 2;
        for (int y = 0; y < img->height && y+oy < sh; y++) {
            if (y+oy < 0) continue;
            for (int x = 0; x < img->width && x+ox < sw; x++) {
                if (x+ox < 0) continue;
                unsigned char *sp = img->data + (y * img->width + x) * 4;
                unsigned char *dp = final->data + ((y+oy)*sw + (x+ox)) * 4;
                /* alpha blend */
                double a = sp[3] / 255.0;
                dp[0] = (unsigned char)(sp[0]*a + dp[0]*(1-a));
                dp[1] = (unsigned char)(sp[1]*a + dp[1]*(1-a));
                dp[2] = (unsigned char)(sp[2]*a + dp[2]*(1-a));
            }
        }
    } else {
        /* scaled (default): stretch to fill */
        final = scale_image(img, sw, sh);
    }

    apply_wallpaper(dpy, final, screen);
    free_image(img);
    free_image(final);
    XCloseDisplay(dpy);
    return 0;
}
