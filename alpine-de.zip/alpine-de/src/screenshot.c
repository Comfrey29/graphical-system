/*
 * screenshot.c — Alpine Desktop Environment: Screenshot Tool
 * Usage: screenshot full        → full screen capture
 *        screenshot region      → interactive region select
 * Saves to ~/Pictures/screenshot-YYYY-MM-DD-HH-MM-SS.png
 * Compile: gcc -O2 -o screenshot screenshot.c -lX11 -lXext -lpng -lm
 */
#include "../include/common.h"
#include <png.h>
#include <sys/stat.h>

/* ── Save XImage as PNG ───────────────────────────────────────────── */
static int save_png(const char *path, XImage *xi, int x, int y, int w, int h) {
    FILE *f = fopen(path, "wb");
    if (!f) { perror("screenshot: fopen"); return 0; }

    png_structp png = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (!png) { fclose(f); return 0; }
    png_infop info = png_create_info_struct(png);
    if (!info) { png_destroy_write_struct(&png, NULL); fclose(f); return 0; }

    if (setjmp(png_jmpbuf(png))) {
        png_destroy_write_struct(&png, &info);
        fclose(f);
        return 0;
    }

    png_init_io(png, f);
    png_set_IHDR(png, info, w, h, 8,
                 PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
                 PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
    png_write_info(png, info);

    unsigned char *row = malloc(w * 3);
    for (int row_y = 0; row_y < h; row_y++) {
        for (int col_x = 0; col_x < w; col_x++) {
            unsigned long pixel = XGetPixel(xi, x + col_x, y + row_y);
            row[col_x*3+0] = (pixel >> 16) & 0xFF;
            row[col_x*3+1] = (pixel >>  8) & 0xFF;
            row[col_x*3+2] =  pixel        & 0xFF;
        }
        png_write_row(png, row);
    }
    free(row);

    png_write_end(png, NULL);
    png_destroy_write_struct(&png, &info);
    fclose(f);
    return 1;
}

/* ── Build output path ────────────────────────────────────────────── */
static void build_path(char *buf, size_t sz) {
    const char *home = getenv("HOME");
    if (!home) home = "/tmp";
    /* ensure ~/Pictures exists */
    char pics[512];
    snprintf(pics, sizeof(pics), "%s/Pictures", home);
    mkdir(pics, 0755);

    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    snprintf(buf, sz, "%s/Pictures/screenshot-%04d-%02d-%02d-%02d-%02d-%02d.png",
             home,
             tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
             tm->tm_hour, tm->tm_min, tm->tm_sec);
}

/* ── Full-screen capture ──────────────────────────────────────────── */
static int screenshot_full(Display *dpy) {
    int screen = DefaultScreen(dpy);
    Window root = RootWindow(dpy, screen);
    int sw = DisplayWidth(dpy, screen);
    int sh = DisplayHeight(dpy, screen);

    XImage *xi = XGetImage(dpy, root, 0, 0, sw, sh, AllPlanes, ZPixmap);
    if (!xi) { fprintf(stderr, "screenshot: XGetImage failed\n"); return 0; }

    char path[512];
    build_path(path, sizeof(path));
    int ok = save_png(path, xi, 0, 0, sw, sh);
    XDestroyImage(xi);

    if (ok) {
        fprintf(stdout, "screenshot: saved to %s\n", path);
        /* notify */
        char cmd[640];
        snprintf(cmd, sizeof(cmd), "notify 'Captura de pantalla' '%s'", path);
        spawn(cmd);
    }
    return ok;
}

/* ── Region selection (rubber-band) ──────────────────────────────── */
static int screenshot_region(Display *dpy) {
    int screen = DefaultScreen(dpy);
    Window root = RootWindow(dpy, screen);
    int sw = DisplayWidth(dpy, screen);
    int sh = DisplayHeight(dpy, screen);

    /* grab pointer */
    Cursor cross = XCreateFontCursor(dpy, 34); /* XC_crosshair */
    int grabbed = XGrabPointer(dpy, root, False,
                               ButtonPressMask|ButtonReleaseMask|PointerMotionMask,
                               GrabModeAsync, GrabModeAsync,
                               root, cross, CurrentTime);
    if (grabbed != GrabSuccess) {
        fprintf(stderr, "screenshot: cannot grab pointer\n");
        return 0;
    }
    /* also grab keyboard to allow Escape */
    XGrabKeyboard(dpy, root, False, GrabModeAsync, GrabModeAsync, CurrentTime);

    /* overlay window for rubber-band */
    XSetWindowAttributes wa;
    wa.override_redirect = True;
    wa.background_pixel  = 0;
    wa.border_pixel      = 0;
    Window overlay = XCreateWindow(dpy, root, 0, 0, sw, sh, 0,
                                   CopyFromParent, InputOutput, CopyFromParent,
                                   CWOverrideRedirect, &wa);
    XMapRaised(dpy, overlay);

    GC gc = XCreateGC(dpy, overlay, 0, NULL);
    XSetFunction(dpy, gc, GXxor);
    XSetForeground(dpy, gc, 0x00FFFFFF);
    XSetSubwindowMode(dpy, gc, IncludeInferiors);

    int x1=-1,y1=-1, x2=-1,y2=-1, px=-1,py=-1;
    int done = 0, cancelled = 0;

    while (!done) {
        XEvent ev;
        XNextEvent(dpy, &ev);
        switch (ev.type) {
            case KeyPress: {
                KeySym sym = XkbKeycodeToKeysym(dpy, ev.xkey.keycode, 0, 0);
                if (sym == XK_Escape) { cancelled = 1; done = 1; }
                break;
            }
            case ButtonPress:
                x1 = x2 = ev.xbutton.x_root;
                y1 = y2 = ev.xbutton.y_root;
                px = x1; py = y1;
                break;
            case MotionNotify:
                if (x1 < 0) break;
                /* erase old rect */
                if (px >= 0) {
                    int rx=MIN(x1,px),ry=MIN(y1,py);
                    int rw=abs(px-x1),rh=abs(py-y1);
                    if (rw>0&&rh>0) XDrawRectangle(dpy,overlay,gc,rx,ry,rw,rh);
                }
                x2 = ev.xmotion.x_root;
                y2 = ev.xmotion.y_root;
                /* draw new rect */
                {
                    int rx=MIN(x1,x2),ry=MIN(y1,y2);
                    int rw=abs(x2-x1),rh=abs(y2-y1);
                    if (rw>0&&rh>0) XDrawRectangle(dpy,overlay,gc,rx,ry,rw,rh);
                }
                px=x2; py=y2;
                XFlush(dpy);
                break;
            case ButtonRelease:
                done = 1;
                break;
        }
    }

    XDestroyWindow(dpy, overlay);
    XFreeGC(dpy, gc);
    XUngrabPointer(dpy, CurrentTime);
    XUngrabKeyboard(dpy, CurrentTime);
    XFreeCursor(dpy, cross);
    XFlush(dpy);

    if (cancelled || x1 < 0 || x2 < 0) return 0;

    int rx = MIN(x1,x2), ry = MIN(y1,y2);
    int rw = abs(x2-x1), rh = abs(y2-y1);
    if (rw < 2 || rh < 2) return 0;

    /* grab the screen */
    XSync(dpy, False);
    usleep(100000); /* 100ms settle */

    XImage *xi = XGetImage(dpy, root, rx, ry, rw, rh, AllPlanes, ZPixmap);
    if (!xi) return 0;

    char path[512];
    build_path(path, sizeof(path));
    int ok = save_png(path, xi, 0, 0, rw, rh);
    XDestroyImage(xi);

    if (ok) {
        fprintf(stdout, "screenshot: saved to %s\n", path);
        char cmd[640];
        snprintf(cmd, sizeof(cmd), "notify 'Captura de pantalla' '%s'", path);
        spawn(cmd);
    }
    return ok;
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(int argc, char *argv[]) {
    signal(SIGCHLD, SIG_IGN);
    Display *dpy = XOpenDisplay(NULL);
    if (!dpy) { fprintf(stderr, "screenshot: cannot open display\n"); return 1; }

    int ok = 0;
    if (argc < 2 || strcmp(argv[1], "full") == 0) {
        ok = screenshot_full(dpy);
    } else if (strcmp(argv[1], "region") == 0) {
        ok = screenshot_region(dpy);
    } else {
        fprintf(stderr, "Usage: screenshot [full|region]\n");
    }

    XCloseDisplay(dpy);
    return ok ? 0 : 1;
}
