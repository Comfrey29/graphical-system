#!/bin/sh
# install-deps.sh — Install build dependencies on Alpine Linux aarch64
# Run as root: sh install-deps.sh
# ════════════════════════════════════════════════════════════════════
set -e

echo "═══════════════════════════════════════════"
echo " Alpine Desktop Environment — Dependencies "
echo "═══════════════════════════════════════════"

# ── Enable community and edge repos if needed ────────────────────────
REPO_FILE="/etc/apk/repositories"
if ! grep -q "^http.*community" "$REPO_FILE" 2>/dev/null; then
    echo "Enabling community repo..."
    sed -i 's|^#\(.*community\)|\1|' "$REPO_FILE"
fi

apk update

# ── Core X11 ─────────────────────────────────────────────────────────
echo "[1/6] Installing X11 core..."
apk add --no-cache \
    xorg-server \
    xorg-server-dev \
    xinit \
    xrandr \
    xset \
    xsetroot \
    libx11 \
    libx11-dev \
    libxext \
    libxext-dev \
    libxrender \
    libxrender-dev \
    libxcomposite \
    libxcomposite-dev \
    libxfixes \
    libxfixes-dev \
    libxft \
    libxft-dev \
    libxkbcommon \
    libxkbcommon-dev

# ── Font rendering ────────────────────────────────────────────────────
echo "[2/6] Installing font stack..."
apk add --no-cache \
    fontconfig \
    fontconfig-dev \
    freetype \
    freetype-dev \
    font-dejavu \
    font-noto \
    font-noto-emoji \
    ttf-liberation

# Try to get a nice sans-serif (Inter as SF Pro substitute)
apk add --no-cache font-inter 2>/dev/null || \
apk add --no-cache font-cantarell 2>/dev/null || true

# JetBrains Mono for terminal
apk add --no-cache font-jetbrains-mono-nerd 2>/dev/null || \
apk add --no-cache font-jetbrains-mono 2>/dev/null || true

fc-cache -fv >/dev/null 2>&1 || true

# ── PNG ───────────────────────────────────────────────────────────────
echo "[3/6] Installing image libs..."
apk add --no-cache \
    libpng \
    libpng-dev

# ── ALSA (audio/volume) ───────────────────────────────────────────────
echo "[4/6] Installing ALSA..."
apk add --no-cache \
    alsa-lib \
    alsa-lib-dev \
    alsa-utils

# ── Compositor ────────────────────────────────────────────────────────
echo "[5/6] Installing compositor..."
apk add --no-cache picom 2>/dev/null || \
apk add --no-cache compton 2>/dev/null || \
echo "  Warning: no compositor found (optional, install picom manually)"

# ── Build tools ───────────────────────────────────────────────────────
echo "[6/6] Installing build tools..."
apk add --no-cache \
    gcc \
    make \
    pkgconf \
    musl-dev \
    linux-headers

# ── Optional apps for dock ────────────────────────────────────────────
echo "[opt] Installing optional dock apps..."
apk add --no-cache \
    xterm \
    thunar \
    firefox 2>/dev/null || true

# ── Input drivers ─────────────────────────────────────────────────────
apk add --no-cache \
    xf86-input-libinput \
    libinput \
    eudev 2>/dev/null || true

echo ""
echo "════════════════════════════════════════════"
echo " All dependencies installed!"
echo " Now build the DE:"
echo ""
echo "   cd alpine-de"
echo "   make"
echo "   make install"
echo ""
echo " Then start with:"
echo "   startx"
echo "════════════════════════════════════════════"
